# Frontend checkout fee display update

I could not safely identify the exact frontend file from the repository index available here, so do this in the checkout summary component that currently shows the 0.75% line item.

## Old behavior
- buyer total = gross + 0.75%
- fee shown as an added buyer charge

## New behavior
- buyer total = gross only
- 0.75% is taken from seller proceeds
- seller net = gross * 0.9925

## Replace summary logic with
```ts
const gross = pricePerTonne * volumeTonnes;
const platformFee = gross * 0.0075;
const sellerNet = gross - platformFee;

const summaryRows = [
  { label: 'Gross trade amount', value: gross },
  { label: 'Buyer total', value: gross },
  { label: 'UAIU platform fee (deducted from seller proceeds)', value: platformFee },
  { label: 'Estimated seller net', value: sellerNet },
];
```

## UI copy
Use copy similar to:
- `Buyer pays the gross trade amount only.`
- `UAIU retains a 0.75% platform fee from seller proceeds.`
- `Seller receives 99.25% through Stripe Connect settlement.`
