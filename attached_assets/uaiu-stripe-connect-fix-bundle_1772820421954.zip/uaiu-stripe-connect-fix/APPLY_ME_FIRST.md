# UAIU Stripe Connect destination-charge fix bundle

This zip is a **drop-in patch bundle**, not a full rebuilt repository.

What is included:
- SQL migration for the required DB columns
- patch snippets for the server files you flagged
- payout email addition
- checkout fee-model update notes
- replit.md doc update

Important:
- I could patch the backend paths from the repository content I could access.
- I could **not safely locate the exact frontend checkout component** that renders the 0.75% fee line item, so I included the exact UI logic change in `patches/frontend_checkout_fee_display_NOTE.md` instead of guessing the wrong file.
- I could not run `npx tsc --noEmit` from the live repo in this environment, so this is a best-effort code patch and should be type-checked in Replit after import.

## Apply order
1. Run `migrations/2026-03-06-stripe-destination-charges.sql`
2. Apply the patches in `patches/`
3. Restart the Replit workflow
4. Test:
   - `/api/exchange/spot-checkout`
   - `/api/escrow/create`
   - `/api/escrow/release`
   - `/api/exchange/payout/release/:tradeId`
   - `checkout.session.completed` webhook
   - seller payout email after destination charge settlement

## Core behavior after patch
- Buyer pays **gross only**
- UAIU receives **0.75% application_fee_amount**
- Seller receives **99.25% directly to their Connect account**
- `platform_collect` remains as documented fallback only
- destination-charge trades skip `createTransfer()` during payout release
