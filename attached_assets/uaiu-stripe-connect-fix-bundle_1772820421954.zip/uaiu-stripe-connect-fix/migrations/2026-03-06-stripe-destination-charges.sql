-- UAIU destination-charge migration

ALTER TABLE exchange_listings
  ADD COLUMN IF NOT EXISTS seller_profile_id varchar REFERENCES seller_profiles(id) ON DELETE SET NULL;

ALTER TABLE seller_payouts
  ADD COLUMN IF NOT EXISTS settlement_method varchar NOT NULL DEFAULT 'platform_collect';

ALTER TABLE seller_payouts
  ADD COLUMN IF NOT EXISTS stripe_destination_charge_id varchar;

ALTER TABLE seller_payouts
  ADD COLUMN IF NOT EXISTS stripe_transfer_id varchar;

ALTER TABLE seller_payouts
  ADD COLUMN IF NOT EXISTS updated_at timestamp DEFAULT NOW();

CREATE INDEX IF NOT EXISTS idx_exchange_listings_seller_profile_id
  ON exchange_listings (seller_profile_id);

CREATE INDEX IF NOT EXISTS idx_seller_payouts_trade_id
  ON seller_payouts (trade_id);

CREATE INDEX IF NOT EXISTS idx_seller_payouts_settlement_method
  ON seller_payouts (settlement_method);
