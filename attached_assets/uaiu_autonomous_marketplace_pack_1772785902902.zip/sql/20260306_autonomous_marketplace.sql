BEGIN;

CREATE TABLE IF NOT EXISTS seller_profiles (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  exchange_account_email varchar NOT NULL UNIQUE,
  legal_entity_name varchar NOT NULL,
  trading_name varchar,
  seller_type varchar NOT NULL DEFAULT 'corporate',
  country varchar,
  registry_name varchar,
  registry_account_id varchar,
  website varchar,
  tax_id varchar,
  payout_method varchar,
  payout_reference varchar,
  onboarding_status varchar NOT NULL DEFAULT 'pending_kyb',
  kyb_status varchar NOT NULL DEFAULT 'not_started',
  kyc_status varchar NOT NULL DEFAULT 'not_started',
  risk_score integer NOT NULL DEFAULT 0,
  auto_approved boolean NOT NULL DEFAULT false,
  last_reviewed_at timestamp,
  created_at timestamp NOT NULL DEFAULT NOW(),
  updated_at timestamp NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS seller_documents (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  seller_profile_id varchar NOT NULL REFERENCES seller_profiles(id) ON DELETE CASCADE,
  document_type varchar NOT NULL,
  file_name varchar NOT NULL,
  file_url varchar,
  hash_sha256 varchar,
  verification_status varchar NOT NULL DEFAULT 'pending',
  detail text,
  created_at timestamp NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS seller_inventory_verifications (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  seller_profile_id varchar NOT NULL REFERENCES seller_profiles(id) ON DELETE CASCADE,
  listing_submission_id varchar,
  registry_serial varchar,
  standard varchar,
  requested_volume_tonnes real,
  verified_volume_tonnes real,
  verification_status varchar NOT NULL DEFAULT 'pending',
  verification_method varchar NOT NULL DEFAULT 'manual_plus_rules',
  evidence_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp NOT NULL DEFAULT NOW(),
  verified_at timestamp
);

CREATE TABLE IF NOT EXISTS exchange_listing_review_queue (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  listing_submission_id varchar NOT NULL,
  seller_profile_id varchar REFERENCES seller_profiles(id) ON DELETE SET NULL,
  decision varchar NOT NULL DEFAULT 'pending',
  reason varchar,
  rule_hits jsonb NOT NULL DEFAULT '[]'::jsonb,
  auto_decision boolean NOT NULL DEFAULT false,
  priority integer NOT NULL DEFAULT 100,
  created_at timestamp NOT NULL DEFAULT NOW(),
  decided_at timestamp
);

CREATE TABLE IF NOT EXISTS exchange_rfq_matches (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  rfq_id varchar NOT NULL,
  listing_id varchar NOT NULL,
  seller_profile_id varchar REFERENCES seller_profiles(id) ON DELETE SET NULL,
  buyer_email varchar NOT NULL,
  seller_email varchar NOT NULL,
  standard varchar NOT NULL,
  matched_volume_tonnes real NOT NULL,
  matched_price_per_tonne real NOT NULL,
  status varchar NOT NULL DEFAULT 'proposed',
  negotiation_summary text,
  confidence integer NOT NULL DEFAULT 0,
  created_at timestamp NOT NULL DEFAULT NOW(),
  updated_at timestamp NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS exchange_settlement_runs (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  trade_id varchar NOT NULL,
  payout_id varchar,
  seller_email varchar NOT NULL,
  buyer_email varchar,
  gross_eur real NOT NULL DEFAULT 0,
  fee_eur real NOT NULL DEFAULT 0,
  seller_net_eur real NOT NULL DEFAULT 0,
  settlement_status varchar NOT NULL DEFAULT 'pending',
  detail jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp NOT NULL DEFAULT NOW(),
  settled_at timestamp
);

CREATE TABLE IF NOT EXISTS seller_payouts (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  trade_id varchar NOT NULL,
  seller_profile_id varchar REFERENCES seller_profiles(id) ON DELETE SET NULL,
  seller_email varchar NOT NULL,
  gross_eur real NOT NULL DEFAULT 0,
  fee_eur real NOT NULL DEFAULT 0,
  seller_net_eur real NOT NULL DEFAULT 0,
  payout_status varchar NOT NULL DEFAULT 'pending_release',
  payout_provider varchar NOT NULL DEFAULT 'workflow_only',
  payout_reference varchar,
  failure_reason text,
  created_at timestamp NOT NULL DEFAULT NOW(),
  released_at timestamp
);

CREATE TABLE IF NOT EXISTS exchange_exception_queue (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid()::varchar,
  entity_type varchar NOT NULL,
  entity_id varchar NOT NULL,
  severity varchar NOT NULL DEFAULT 'medium',
  status varchar NOT NULL DEFAULT 'open',
  code varchar NOT NULL,
  message text NOT NULL,
  detail jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp NOT NULL DEFAULT NOW(),
  resolved_at timestamp,
  resolved_by varchar
);

CREATE INDEX IF NOT EXISTS idx_seller_profiles_email ON seller_profiles(exchange_account_email);
CREATE INDEX IF NOT EXISTS idx_inventory_verifications_status ON seller_inventory_verifications(verification_status);
CREATE INDEX IF NOT EXISTS idx_review_queue_decision ON exchange_listing_review_queue(decision, priority, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_rfq_matches_status ON exchange_rfq_matches(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_settlement_runs_trade ON exchange_settlement_runs(trade_id);
CREATE INDEX IF NOT EXISTS idx_seller_payouts_status ON seller_payouts(payout_status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_exception_queue_status ON exchange_exception_queue(status, severity, created_at DESC);

COMMIT;
