-- T009 / T011
CREATE TABLE IF NOT EXISTS sessions (
  id varchar PRIMARY KEY,
  user_id varchar NOT NULL,
  user_email varchar NOT NULL,
  created_at timestamp NOT NULL DEFAULT NOW(),
  expires_at timestamp NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);

ALTER TABLE exchange_trades
  ADD CONSTRAINT chk_exchange_trades_volume_positive CHECK (volume_tonnes > 0),
  ADD CONSTRAINT chk_exchange_trades_gross_positive CHECK (gross_eur > 0),
  ADD CONSTRAINT chk_exchange_trades_price_positive CHECK (price_per_tonne > 0);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'uq_exchange_trades_trade_id'
  ) THEN
    ALTER TABLE exchange_trades
      ADD CONSTRAINT uq_exchange_trades_trade_id UNIQUE (trade_id);
  END IF;
END$$;

DELETE FROM exchange_sessions WHERE expires_at <= NOW();
DELETE FROM sessions WHERE expires_at <= NOW();
