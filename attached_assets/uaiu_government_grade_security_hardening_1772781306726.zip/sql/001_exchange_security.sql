-- T001 / T004 / T008
CREATE TABLE IF NOT EXISTS exchange_sessions (
  id SERIAL PRIMARY KEY,
  email varchar NOT NULL,
  token varchar NOT NULL UNIQUE,
  created_at timestamp NOT NULL DEFAULT NOW(),
  expires_at timestamp NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_exchange_sessions_token ON exchange_sessions(token);
CREATE INDEX IF NOT EXISTS idx_exchange_sessions_email ON exchange_sessions(email);
CREATE INDEX IF NOT EXISTS idx_exchange_sessions_expires_at ON exchange_sessions(expires_at);

ALTER TABLE exchange_accounts
  ADD COLUMN IF NOT EXISTS failed_login_attempts integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS locked_until timestamp;

CREATE TABLE IF NOT EXISTS exchange_security_log (
  id SERIAL PRIMARY KEY,
  email varchar,
  event_type varchar NOT NULL,
  ip varchar,
  detail jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamp NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_exchange_security_log_created_at ON exchange_security_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_exchange_security_log_event_type ON exchange_security_log(event_type);
CREATE INDEX IF NOT EXISTS idx_exchange_security_log_email ON exchange_security_log(email);
