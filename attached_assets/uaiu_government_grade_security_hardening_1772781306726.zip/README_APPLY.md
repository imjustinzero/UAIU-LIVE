# UAIU.LIVE/X Government-Grade Security Hardening Pack

This pack is a best-effort implementation kit for the 12 findings you listed.
It is designed for your current repo layout and can be dropped into Replit, but I could not run your full app, DB migrations, or end-to-end Stripe/Daily/Zoho flows from here.

## What is included
- `server/exchange-auth.ts` — DB-backed exchange token auth, admin header auth, safe error helper
- `server/security-utils.ts` — reusable logging and timing-safe helpers
- `sql/001_exchange_security.sql` — exchange sessions, security log, account lockout fields
- `sql/002_persistent_sessions_and_constraints.sql` — durable sessions + DB constraints
- `patches/*.patch` — focused file patches for your existing repo
- `package-additions.json` — npm deps to add

## Required npm installs
Add these packages:
- express-rate-limit
- helmet
- dompurify
- @types/dompurify

## Apply order
1. Run `sql/001_exchange_security.sql`
2. Run `sql/002_persistent_sessions_and_constraints.sql`
3. Add packages from `package-additions.json`
4. Drop in:
   - `server/exchange-auth.ts`
   - `server/security-utils.ts`
5. Apply the patch files in `patches/`
6. Restart the app
7. Verify acceptance cases

## Important
This pack intentionally:
- moves admin auth to `X-Admin-Key`
- moves exchange auth to `X-Exchange-Token`
- removes the public `/api/exchange/trade/record` route
- sanitizes 500-level exchange errors
- enforces KYC on checkout and retirement
- server-locks spot pricing to DB listings
