-- ═══════════════════════════════════════════════════════════════════════════
--  UAIU.LIVE/X — DATABASE MIGRATION
--  Run this ONE TIME in your Neon PostgreSQL console (or Replit DB shell)
--  before deploying the updated routes.ts and storage.ts
-- ═══════════════════════════════════════════════════════════════════════════

-- 1. Add KYC columns to exchange_accounts
ALTER TABLE exchange_accounts
  ADD COLUMN IF NOT EXISTS kyc_session_id   TEXT,
  ADD COLUMN IF NOT EXISTS kyc_status       TEXT DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS kyc_verified_at  TIMESTAMPTZ;

-- 2. PostgreSQL fallback for escrow settlement logging
--    (used when Supabase is unavailable — ensures no silent data loss)
CREATE TABLE IF NOT EXISTS escrow_settlements_log (
  id                  SERIAL PRIMARY KEY,
  trade_id            TEXT NOT NULL,
  payment_intent_id   TEXT UNIQUE NOT NULL,
  amount_eur          NUMERIC(12, 2),
  uaiu_fee_eur        NUMERIC(12, 2),
  seller_net_eur      NUMERIC(12, 2),
  status              TEXT DEFAULT 'held',
  settled_at          TIMESTAMPTZ,
  stripe_charge_id    TEXT,
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_escrow_log_trade_id
  ON escrow_settlements_log (trade_id);

CREATE INDEX IF NOT EXISTS idx_escrow_log_payment_intent
  ON escrow_settlements_log (payment_intent_id);

-- 3. Index on exchange_credit_listings for fast seller dashboard lookups
CREATE INDEX IF NOT EXISTS idx_credit_listings_email
  ON exchange_credit_listings (LOWER(email));

-- ═══════════════════════════════════════════════════════════════════════════
--  REPLIT SECRETS — Add these in Replit → Tools → Secrets
-- ═══════════════════════════════════════════════════════════════════════════

-- STRIPE_WEBHOOK_UUID     = [copy from server logs on first boot after deploy]
-- STRIPE_WEBHOOK_SECRET   = [from Stripe Dashboard → Webhooks → Signing secret]
-- PARTNER_API_KEY         = [any strong string — give to Alki's dev team]
-- ADMIN_SECRET_KEY        = [any strong string — protects /api/admin/health-check]

-- ═══════════════════════════════════════════════════════════════════════════
--  STRIPE DASHBOARD SETUP
-- ═══════════════════════════════════════════════════════════════════════════

-- 1. Stripe Dashboard → Developers → Webhooks → Add endpoint
-- 2. URL: https://uaiu.live/api/stripe/webhook/[YOUR STRIPE_WEBHOOK_UUID]
-- 3. Events to enable:
--      payment_intent.amount_capturable_updated   ← auto escrow release
--      payment_intent.succeeded
--      payment_intent.payment_failed
--      identity.verification_session.verified     ← auto KYC confirm
--      identity.verification_session.requires_input
-- 4. Copy Signing secret → add as STRIPE_WEBHOOK_SECRET in Replit Secrets

-- ═══════════════════════════════════════════════════════════════════════════
--  PARTNER API — What to send Alki's tech team
-- ═══════════════════════════════════════════════════════════════════════════

-- Endpoint: POST https://uaiu.live/api/partner/listings
-- Headers:  Content-Type: application/json
--
-- Body:
-- {
--   "api_key": "[PARTNER_API_KEY]",
--   "listings": [
--     {
--       "name":            "SwissX B100 Biofuel Credits",
--       "standard":        "VCS",
--       "badgeLabel":      "VCS",
--       "origin":          "Antigua, Caribbean - FOB Bunkering",
--       "pricePerTonne":   71.80,
--       "changePercent":   4.2,
--       "changeDirection": "up"
--     },
--     {
--       "name":            "SwissX Soil Amendment Credits",
--       "standard":        "GOLD STD",
--       "badgeLabel":      "GOLD STD",
--       "origin":          "Caribbean Basin - Agricultural",
--       "pricePerTonne":   45.00,
--       "changePercent":   2.1,
--       "changeDirection": "up"
--     }
--   ]
-- }

-- ═══════════════════════════════════════════════════════════════════════════
--  HEALTH CHECK — Run after deploying to confirm everything is live
-- ═══════════════════════════════════════════════════════════════════════════

-- GET https://uaiu.live/api/admin/health-check?admin_key=[ADMIN_SECRET_KEY]
--
-- All systems green = safe to onboard Swiss X REDD UK Limited
