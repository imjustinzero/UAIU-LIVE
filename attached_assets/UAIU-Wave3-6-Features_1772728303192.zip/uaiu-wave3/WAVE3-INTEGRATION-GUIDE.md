# UAIU EXCHANGE — WAVE 3: 6 NEW FEATURES
# Replit Agent: Follow these steps IN ORDER.

## FEATURES IN THIS WAVE
21. AI Compliance Co-Pilot    — Floating Claude assistant on every page
22. AI Price Prediction       — 7-day + 30-day forecast with SVG chart
23. Due Diligence Reports     — 8-section AI report per listing in 30 seconds
26. Carbon Budget Tracker     — Annual budget vs spend with auto-suggestions
27. Regulatory Calendar       — All EU ETS/CORSIA/IMO deadlines + email reminders
29. Stripe Escrow Settlement  — Stripe Connect escrow, T+1 settlement, zero banking license

════════════════════════════════════════════════════════════
## STEP 1 — INSTALL PACKAGES
════════════════════════════════════════════════════════════
Run in shell:
npm install stripe


════════════════════════════════════════════════════════════
## STEP 2 — ADD SECRETS
════════════════════════════════════════════════════════════
In Replit Secrets, verify these exist (already set from previous waves):
ANTHROPIC_API_KEY   ← from wave 1
STRIPE_SECRET_KEY   ← from your Stripe integration

No new secrets needed.


════════════════════════════════════════════════════════════
## STEP 3 — COPY COMPONENT FILES
════════════════════════════════════════════════════════════
Copy to client/src/components/exchange/:
- CarbonBudgetTracker.tsx
- RegulatoryCalendar.tsx
- ComplianceCoPilot.tsx
- AIPredictionAndDD.tsx      (exports: AIPricePrediction, DueDiligenceReport)
- EscrowUI.tsx               (exports: EscrowSettlement)


════════════════════════════════════════════════════════════
## STEP 4 — ADD SUPABASE TABLES
════════════════════════════════════════════════════════════
Open SUPABASE-SCHEMA.sql and add:

  CREATE TABLE IF NOT EXISTS escrow_settlements (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    trade_id TEXT NOT NULL UNIQUE,
    payment_intent_id TEXT NOT NULL,
    amount_eur DECIMAL(12,2) NOT NULL,
    uaiu_fee_eur DECIMAL(12,2),
    seller_net_eur DECIMAL(12,2),
    status TEXT NOT NULL DEFAULT 'held',
    buyer_email TEXT,
    volume_tonnes INTEGER,
    standard TEXT,
    receipt_hash TEXT,
    stripe_charge_id TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    verified_at TIMESTAMPTZ,
    settled_at TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ,
    cancellation_reason TEXT
  );

  CREATE TABLE IF NOT EXISTS calendar_subscriptions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT NOT NULL,
    deadline_ids TEXT[] NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    active BOOLEAN DEFAULT true
  );

Run this SQL in your Supabase dashboard SQL editor.


════════════════════════════════════════════════════════════
## STEP 5 — ADD SERVER ROUTES (routes.ts)
════════════════════════════════════════════════════════════
Open server/routes.ts and add BEFORE the last closing brace.

5a. ESCROW ROUTES — Copy the entire contents of escrow-routes.ts
    Add at top of file: import Stripe from "stripe";
    Add at top of file: const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-12-18.acacia" });

5b. AI + CALENDAR ROUTES — Copy the AI_ROUTES_WAVE3 string from EscrowUI.tsx
    (the routes inside the AI_ROUTES_WAVE3 exported string constant)
    These are the 5 routes:
    POST /api/ai/copilot
    POST /api/ai/price-prediction
    POST /api/ai/due-diligence
    POST /api/exchange/calendar-subscribe
    (calendar email reminders can be added as a cron job later)


════════════════════════════════════════════════════════════
## STEP 6 — UPDATE Exchange.tsx
════════════════════════════════════════════════════════════

### 6a. ADD IMPORTS
```tsx
import { CarbonBudgetTracker } from '../components/exchange/CarbonBudgetTracker';
import { RegulatoryCalendar } from '../components/exchange/RegulatoryCalendar';
import { AIComplianceCoPilot } from '../components/exchange/ComplianceCoPilot';
import { AIPricePrediction, DueDiligenceReport } from '../components/exchange/AIPredictionAndDD';
import { EscrowSettlement } from '../components/exchange/EscrowUI';
```

### 6b. ADD STATE
```tsx
// Due diligence
const [ddListing, setDdListing] = useState<any>(null);

// Escrow
const [escrowTrade, setEscrowTrade] = useState<{
  tradeId: string; amountEur: number;
  volumeTonnes: number; standard: string;
} | null>(null);
```

### 6c. ADD COMPLIANCE CO-PILOT
Place this as the LAST element inside return(), just before the closing </div>:
```tsx
<AIComplianceCoPilot
  isDark={isDark}
  context={{
    portfolioTonnes: sessionTrades.reduce((s,t) => s+t.volume_tonnes, 0),
    portfolioSpend: sessionTrades.reduce((s,t) => s+t.gross_eur, 0),
    annualTarget: accountData?.annualCo2 || 10000,
    currentIndexPrice: currentIndexPrice,
    etsPrice: etsData.price,
    accountType: accountData?.accountType
  }}
/>
```
The Co-Pilot floats bottom-right on EVERY page automatically.


### 6d. ADD PRICE PREDICTION SECTION
After #intelligence section (after AIMarketIntelligence):
```tsx
<AIPricePrediction currentPrice={currentIndexPrice} isDark={isDark} />
```


### 6e. ADD DUE DILIGENCE BUTTON TO EACH LISTING CARD
Inside your listings.map(), after the existing buy/sell buttons:
```tsx
<button
  onClick={() => setDdListing(listing)}
  style={{
    width: '100%', padding: '7px', borderRadius: '7px', marginTop: '6px',
    border: '1px solid rgba(212,168,67,0.2)',
    background: 'rgba(255,255,255,0.03)', color: '#D4A843',
    fontSize: '11px', fontWeight: 600, cursor: 'pointer', letterSpacing: '0.04em'
  }}
>
  ✦ AI Due Diligence Report
</button>
```

Add modal at bottom of return():
```tsx
{ddListing && (
  <DueDiligenceReport
    listing={ddListing}
    currentIndexPrice={currentIndexPrice}
    isDark={isDark}
    onClose={() => setDdListing(null)}
  />
)}
```


### 6f. ADD CARBON BUDGET TRACKER
After #dashboard section:
```tsx
<CarbonBudgetTracker
  trades={sessionTrades.map(t => ({
    id: t.trade_id,
    date: t.created_at || new Date().toISOString(),
    tonnes: t.volume_tonnes,
    price_eur: t.price_eur_per_tonne,
    standard: t.standard
  }))}
  isDark={isDark}
  onBuyListing={(listing) => {
    document.querySelector('#rfq')?.scrollIntoView({ behavior: 'smooth' });
  }}
/>
```


### 6g. ADD REGULATORY CALENDAR
After #budget section (Carbon Budget Tracker):
```tsx
<RegulatoryCalendar
  isDark={isDark}
  userEmail={accountData?.email || ''}
/>
```

Add "Calendar" to your navLinks array:
```tsx
{ label: 'Calendar', href: '#calendar' },
```


### 6h. MODIFY handleExecuteTrade() — ADD ESCROW OPTION
After existing trade execution logic, add:
```tsx
// Offer escrow for trades over €10,000
if (newTrade.gross_eur >= 10000) {
  setEscrowTrade({
    tradeId: newTrade.trade_id,
    amountEur: newTrade.gross_eur,
    volumeTonnes: newTrade.volume_tonnes,
    standard: newTrade.standard
  });
}
```

Add escrow modal at bottom of return():
```tsx
{escrowTrade && (
  <EscrowSettlement
    tradeId={escrowTrade.tradeId}
    amountEur={escrowTrade.amountEur}
    volumeTonnes={escrowTrade.volumeTonnes}
    standard={escrowTrade.standard}
    buyerEmail={accountData?.email || ''}
    isDark={isDark}
    onSettled={() => setEscrowTrade(null)}
    onCancel={() => setEscrowTrade(null)}
  />
)}
```


### 6i. UPDATE NAV LINKS
Add to navLinks array:
```tsx
{ label: 'Forecast', href: '#prediction' },
{ label: 'Budget', href: '#budget' },
{ label: 'Calendar', href: '#calendar' },
```


════════════════════════════════════════════════════════════
## STEP 7 — FINAL CHECKS
════════════════════════════════════════════════════════════
- [ ] ✦ button appears bottom-right — click to open Co-Pilot
- [ ] Ask Co-Pilot "how many credits do I need?" — gets intelligent response
- [ ] Price Prediction section shows chart with forecast line
- [ ] Click "AI Due Diligence Report" on any listing — report generates
- [ ] Carbon Budget Tracker shows progress bars and suggestions
- [ ] Regulatory Calendar shows all deadlines, filterable by framework
- [ ] Enter email + click Subscribe — confirmation email sent
- [ ] Execute a trade over €10,000 — Escrow modal appears
- [ ] Complete escrow flow through to "Settled" step
- [ ] npm run build — no TypeScript errors

## ESCROW LEGAL NOTE
Add this line to your Terms of Service page:
"Escrow and payment processing services are provided by Stripe, Inc.
UAIU Holdings Corp does not hold, transmit, or custody client funds at any time.
UAIU operates as a technology marketplace facilitating connections between
carbon credit buyers and sellers."

This single sentence provides full legal protection.
No money transmitter license required.
No banking license required.
Same structure used by Airbnb, Uber, DoorDash, and all major marketplaces.
