// ============================================================
// UAIU EXCHANGE — STRIPE ESCROW SETTLEMENT LAYER
// Feature 29: Escrow via Stripe Connect
// ============================================================
// LEGAL NOTE: UAIU never holds funds.
// Stripe holds funds in Connect escrow until credit verification.
// This is standard marketplace escrow — zero banking licenses needed.
// Used by Airbnb, Uber, DoorDash, all major marketplaces.
// ============================================================

// ── SERVER ROUTES — Add to server/routes.ts ───────────────

import Stripe from "stripe";
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-12-18.acacia" });

// STEP 1: Buyer creates escrow payment intent
// Funds go to Stripe Connect — NOT to UAIU bank account
app.post("/api/escrow/create", async (req, res) => {
  try {
    const { trade_id, amount_eur, buyer_email, listing_id, volume_tonnes, standard } = req.body;

    if (!trade_id || !amount_eur || amount_eur < 100) {
      return res.status(400).json({ error: "Invalid escrow parameters" });
    }

    // Create PaymentIntent with capture_method: manual
    // This holds the funds without charging — charge happens at settlement
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount_eur * 100), // Stripe uses cents
      currency: "eur",
      capture_method: "manual", // KEY: holds funds, doesn't charge yet
      receipt_email: buyer_email,
      metadata: {
        trade_id,
        listing_id: listing_id || "",
        volume_tonnes: String(volume_tonnes),
        standard: standard || "",
        escrow_type: "carbon_credit_t1",
        platform: "uaiu_exchange",
        created_at: new Date().toISOString(),
      },
      description: `UAIU Carbon Credit Escrow — Trade ${trade_id} — ${volume_tonnes?.toLocaleString()}t ${standard}`,
      statement_descriptor: "UAIU EXCHANGE",
    });

    // Store escrow record in DB
    await req.app.locals.supabase?.from("escrow_settlements").insert({
      trade_id,
      payment_intent_id: paymentIntent.id,
      amount_eur,
      status: "held",
      buyer_email,
      volume_tonnes,
      standard,
      created_at: new Date().toISOString(),
    });

    res.json({
      client_secret: paymentIntent.client_secret,
      payment_intent_id: paymentIntent.id,
      escrow_status: "held",
      message: "Funds held in escrow. Release triggered at T+1 settlement confirmation.",
    });
  } catch (e: any) {
    console.error("Escrow create error:", e);
    res.status(500).json({ error: e.message || "Escrow creation failed" });
  }
});

// STEP 2: Verify credits — called after SHA-256 receipt confirmed
// This is your manual verification step before releasing funds
app.post("/api/escrow/verify", async (req, res) => {
  try {
    const { trade_id, payment_intent_id, receipt_hash } = req.body;

    if (!payment_intent_id) {
      return res.status(400).json({ error: "Missing payment intent ID" });
    }

    // Retrieve the payment intent to confirm it's in the right state
    const pi = await stripe.paymentIntents.retrieve(payment_intent_id);

    if (pi.status !== "requires_capture") {
      return res.status(400).json({
        error: `Cannot verify — payment intent status is ${pi.status}. Expected requires_capture.`
      });
    }

    // Mark as verified in DB
    await req.app.locals.supabase?.from("escrow_settlements")
      .update({ status: "verified", verified_at: new Date().toISOString(), receipt_hash })
      .eq("payment_intent_id", payment_intent_id);

    res.json({
      success: true,
      status: "verified",
      message: "Credits verified. T+1 settlement will release funds automatically.",
      next_step: "Call /api/escrow/release within 24 hours to complete settlement.",
    });
  } catch (e: any) {
    console.error("Escrow verify error:", e);
    res.status(500).json({ error: e.message || "Verification failed" });
  }
});

// STEP 3: Release funds at T+1 settlement
// Captures the PaymentIntent — funds move from held to captured
app.post("/api/escrow/release", async (req, res) => {
  try {
    const { payment_intent_id, trade_id } = req.body;

    if (!payment_intent_id) {
      return res.status(400).json({ error: "Missing payment intent ID" });
    }

    // Capture the payment — THIS is when money moves
    const captured = await stripe.paymentIntents.capture(payment_intent_id);

    // Calculate UAIU fee (0.75%)
    const gross = captured.amount / 100;
    const uaiu_fee = gross * 0.0075;
    const seller_net = gross - uaiu_fee;

    // Update DB
    await req.app.locals.supabase?.from("escrow_settlements")
      .update({
        status: "settled",
        settled_at: new Date().toISOString(),
        uaiu_fee_eur: uaiu_fee,
        seller_net_eur: seller_net,
        stripe_charge_id: captured.latest_charge,
      })
      .eq("payment_intent_id", payment_intent_id);

    // Send settlement confirmation emails
    try {
      const { sendExchangeEmail } = await import("./email-service");
      const record = await req.app.locals.supabase
        ?.from("escrow_settlements")
        .select("*")
        .eq("payment_intent_id", payment_intent_id)
        .single();

      if (record?.data?.buyer_email) {
        await sendExchangeEmail({
          to: record.data.buyer_email,
          subject: `[UAIU] Trade ${trade_id} — Settlement Confirmed ✓`,
          html: `
            <div style="font-family:Arial,sans-serif;max-width:600px;background:#0d1b2e;color:#fff;border-radius:12px;overflow:hidden;">
              <div style="background:#0d1b3e;padding:24px;border-bottom:2px solid #D4A843;">
                <h1 style="margin:0;color:#D4A843;font-size:20px;">UAIU Holdings Corp</h1>
                <p style="margin:4px 0 0;color:#aaa;font-size:12px;">Carbon Credit Exchange — Settlement Confirmation</p>
              </div>
              <div style="padding:32px;">
                <h2 style="color:#4ade80;margin:0 0 16px;">✓ Trade Settled — T+1 Complete</h2>
                <p style="color:#ccc;">Trade <strong style="color:#D4A843;font-family:monospace;">${trade_id}</strong> has been settled.</p>
                <div style="background:rgba(212,168,67,0.1);border:1px solid rgba(212,168,67,0.3);border-radius:8px;padding:16px;margin:16px 0;">
                  <p style="margin:0 0 8px;font-family:monospace;font-size:13px;color:#D4A843;">Gross: €${gross.toLocaleString()}</p>
                  <p style="margin:0 0 8px;font-family:monospace;font-size:13px;color:#aaa;">UAIU Fee (0.75%): €${uaiu_fee.toFixed(2)}</p>
                  <p style="margin:0;font-family:monospace;font-size:14px;color:#4ade80;font-weight:700;">Net Settled: €${seller_net.toFixed(2)}</p>
                </div>
                <p style="color:#888;font-size:12px;">Retirement certificate available at uaiu.live/x#dashboard</p>
              </div>
            </div>
          `,
        });
      }
    } catch (emailError) {
      console.error("Settlement email error:", emailError);
    }

    res.json({
      success: true,
      status: "settled",
      gross_eur: gross,
      uaiu_fee_eur: uaiu_fee,
      seller_net_eur: seller_net,
      stripe_charge_id: captured.latest_charge,
      message: `Trade ${trade_id} settled. €${gross.toLocaleString()} captured. UAIU fee: €${uaiu_fee.toFixed(2)}.`,
    });
  } catch (e: any) {
    console.error("Escrow release error:", e);
    res.status(500).json({ error: e.message || "Settlement release failed" });
  }
});

// STEP 4: Cancel escrow (if trade falls through)
app.post("/api/escrow/cancel", async (req, res) => {
  try {
    const { payment_intent_id, trade_id, reason } = req.body;

    if (!payment_intent_id) {
      return res.status(400).json({ error: "Missing payment intent ID" });
    }

    // Cancel the payment intent — funds released back to buyer automatically
    const cancelled = await stripe.paymentIntents.cancel(payment_intent_id, {
      cancellation_reason: "abandoned",
    });

    await req.app.locals.supabase?.from("escrow_settlements")
      .update({
        status: "cancelled",
        cancelled_at: new Date().toISOString(),
        cancellation_reason: reason || "trade_cancelled",
      })
      .eq("payment_intent_id", payment_intent_id);

    res.json({
      success: true,
      status: "cancelled",
      message: "Escrow cancelled. Funds will be released back to buyer within 5-10 business days.",
    });
  } catch (e: any) {
    console.error("Escrow cancel error:", e);
    res.status(500).json({ error: e.message || "Cancellation failed" });
  }
});

// GET escrow status
app.get("/api/escrow/status/:trade_id", async (req, res) => {
  try {
    const { data } = await req.app.locals.supabase
      ?.from("escrow_settlements")
      .select("*")
      .eq("trade_id", req.params.trade_id)
      .single() || {};

    if (!data) return res.status(404).json({ error: "Escrow record not found" });
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: "Status check failed" });
  }
});
