import fs from "fs";
import { S3Client, ListObjectsV2Command, HeadObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { Upload } from "@aws-sdk/lib-storage";

const DEFAULT_PREFIX = "uaiu-backups/";

export function isS3Configured(): boolean {
  return Boolean(
    process.env.S3_BACKUP_BUCKET &&
    process.env.AWS_ACCESS_KEY_ID &&
    process.env.AWS_SECRET_ACCESS_KEY
  );
}

export function getS3Client(): S3Client | null {
  if (!isS3Configured()) return null;

  const endpoint = process.env.S3_BACKUP_ENDPOINT;
  const region = process.env.AWS_REGION || "us-east-1";

  return new S3Client({
    region,
    endpoint: endpoint || undefined,
    forcePathStyle: Boolean(endpoint),
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
    },
  });
}

function getBucket(): string {
  const bucket = process.env.S3_BACKUP_BUCKET;
  if (!bucket) throw new Error("S3_BACKUP_BUCKET is not configured.");
  return bucket;
}

export async function uploadToS3(localPath: string, key: string): Promise<{ etag: string; versionId?: string }> {
  const client = getS3Client();
  if (!client) throw new Error("S3 backup storage is not configured.");

  if (!fs.existsSync(localPath)) {
    throw new Error(`Backup file not found at ${localPath}`);
  }

  const upload = new Upload({
    client,
    params: {
      Bucket: getBucket(),
      Key: key,
      Body: fs.createReadStream(localPath),
      ContentType: "application/sql",
    },
  });

  try {
    const result = await upload.done();
    return {
      etag: String(result.ETag || "").replaceAll('"', ""),
      versionId: result.VersionId,
    };
  } catch (error: any) {
    throw new Error(`Failed to upload backup to S3-compatible storage: ${error?.message || "unknown error"}`);
  }
}

export async function listS3Backups(): Promise<{ key: string; size: number; lastModified: Date }[]> {
  const client = getS3Client();
  if (!client) return [];

  try {
    const result = await client.send(
      new ListObjectsV2Command({
        Bucket: getBucket(),
        Prefix: DEFAULT_PREFIX,
      })
    );

    return (result.Contents || [])
      .filter((item) => item.Key)
      .map((item) => ({
        key: item.Key!,
        size: Number(item.Size || 0),
        lastModified: item.LastModified || new Date(0),
      }))
      .sort((a, b) => b.lastModified.getTime() - a.lastModified.getTime());
  } catch (error: any) {
    throw new Error(`Failed to list S3 backups: ${error?.message || "unknown error"}`);
  }
}

export async function headS3Object(key: string): Promise<{ size: number; etag: string } | null> {
  const client = getS3Client();
  if (!client) return null;

  try {
    const result = await client.send(
      new HeadObjectCommand({
        Bucket: getBucket(),
        Key: key,
      })
    );

    return {
      size: Number(result.ContentLength || 0),
      etag: String(result.ETag || "").replaceAll('"', ""),
    };
  } catch (error: any) {
    const code = error?.$metadata?.httpStatusCode;
    if (code === 404 || error?.name === "NotFound" || error?.name === "NoSuchKey") {
      return null;
    }
    throw new Error(`Failed to inspect S3 object ${key}: ${error?.message || "unknown error"}`);
  }
}

export async function deleteS3Object(key: string): Promise<void> {
  const client = getS3Client();
  if (!client) return;

  try {
    await client.send(
      new DeleteObjectCommand({
        Bucket: getBucket(),
        Key: key,
      })
    );
  } catch (error: any) {
    throw new Error(`Failed to delete S3 backup ${key}: ${error?.message || "unknown error"}`);
  }
}

export async function pruneS3Backups(keep: number): Promise<string[]> {
  const backups = await listS3Backups();
  if (backups.length <= keep) return [];

  const toDelete = backups.slice(keep);
  const deleted: string[] = [];

  for (const item of toDelete) {
    await deleteS3Object(item.key);
    deleted.push(item.key);
  }

  return deleted;
}
