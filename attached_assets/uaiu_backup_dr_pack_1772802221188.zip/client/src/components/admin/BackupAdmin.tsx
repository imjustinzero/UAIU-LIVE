import { useEffect, useMemo, useState } from "react";

const C = {
  bg: "#05080f",
  surface: "#0d1a2e",
  surface2: "#111f35",
  border: "#1e3050",
  gold: "#d4a843",
  green: "#22c55e",
  red: "#ef4444",
  yellow: "#eab308",
  text: "#e2e8f0",
  muted: "#64748b",
};

type BackupLog = {
  id: string;
  filename: string;
  fileSizeBytes?: number | null;
  checksumSha256?: string | null;
  storagePath?: string | null;
  storageProvider?: string | null;
  uploadStatus?: string | null;
  verifyStatus?: string | null;
  createdAt?: string | null;
};

function formatBytes(bytes?: number | null) {
  if (!bytes) return "—";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let value = bytes;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${value.toFixed(value >= 100 || i === 0 ? 0 : 1)} ${units[i]}`;
}

function badgeColor(value?: string | null) {
  const v = (value || "").toLowerCase();
  if (v.includes("upload") || v === "ok") return C.green;
  if (v.includes("fail") || v.includes("mismatch")) return C.red;
  if (v.includes("pending") || v.includes("local")) return C.yellow;
  return C.muted;
}

export default function BackupAdmin({ adminKey }: { adminKey: string }) {
  const [loading, setLoading] = useState(false);
  const [backups, setBackups] = useState<BackupLog[]>([]);
  const [s3Configured, setS3Configured] = useState(false);
  const [bucketName, setBucketName] = useState<string | null>(null);
  const [message, setMessage] = useState<string>("");

  const headers = useMemo(() => ({ "X-Admin-Key": adminKey, "Content-Type": "application/json" }), [adminKey]);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/backup/list", { headers: { "X-Admin-Key": adminKey } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to load backups");
      setBackups(data.backups || []);
      setS3Configured(Boolean(data.s3Configured));
      setBucketName(data.bucketName || null);
    } catch (error: any) {
      setMessage(error.message || "Failed to load backups");
    } finally {
      setLoading(false);
    }
  }

  async function triggerBackup() {
    setMessage("");
    const res = await fetch("/api/admin/backup/trigger", { method: "POST", headers });
    const data = await res.json();
    if (!res.ok) {
      setMessage(data.error || "Trigger failed");
      return;
    }
    setMessage(`Backup created: ${data.file || data.filename} · ${data.checksumSha256?.slice(0, 12) || ""}`);
    await load();
  }

  async function verifyBackup(id: string) {
    setMessage("");
    const res = await fetch(`/api/admin/backup/verify/${id}`, { method: "POST", headers: { "X-Admin-Key": adminKey } });
    const data = await res.json();
    if (!res.ok) {
      setMessage(data.error || "Verify failed");
      return;
    }
    setMessage(`Verify ${id}: ${data.verifyStatus}`);
    await load();
  }

  useEffect(() => {
    if (adminKey) load();
  }, [adminKey]);

  return (
    <div data-testid="backup-admin-root" style={{ color: C.text }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", marginBottom: 18, flexWrap: "wrap" }}>
        <div>
          <h2 style={{ margin: 0, color: C.gold, fontSize: 18 }}>Backup & Disaster Recovery</h2>
          <p style={{ margin: "6px 0 0", color: C.muted, fontSize: 13 }}>
            Remote retention, metadata logging, and integrity verification for institutional recovery readiness.
          </p>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <span data-testid="badge-s3-configured" style={{ border: `1px solid ${C.border}`, padding: "6px 10px", borderRadius: 999, color: s3Configured ? C.green : C.yellow }}>
            S3: {s3Configured ? "configured" : "not configured"}
          </span>
          <span style={{ border: `1px solid ${C.border}`, padding: "6px 10px", borderRadius: 999, color: C.muted }}>
            Bucket: {bucketName || "—"}
          </span>
          <button data-testid="button-trigger-backup" onClick={triggerBackup} style={{ background: C.gold, color: C.bg, border: "none", borderRadius: 8, padding: "8px 14px", cursor: "pointer", fontWeight: 700 }}>
            Trigger Backup
          </button>
        </div>
      </div>

      {message && <div style={{ marginBottom: 14, color: C.text, background: C.surface2, border: `1px solid ${C.border}`, borderRadius: 8, padding: "10px 12px" }}>{message}</div>}

      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 980 }}>
            <thead style={{ background: C.surface2 }}>
              <tr>
                {["Filename", "Size", "Created", "Checksum", "Storage", "Upload", "Verify", "Actions"].map((label) => (
                  <th key={label} style={{ textAlign: "left", color: C.muted, fontSize: 12, padding: "12px 14px", borderBottom: `1px solid ${C.border}` }}>{label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {!loading && backups.length === 0 && (
                <tr>
                  <td colSpan={8} style={{ padding: 24, textAlign: "center", color: C.muted }}>No backups logged yet.</td>
                </tr>
              )}
              {backups.map((backup) => (
                <tr key={backup.id} data-testid={`row-backup-${backup.id}`} style={{ borderBottom: `1px solid ${C.border}` }}>
                  <td style={{ padding: "12px 14px", fontFamily: "monospace", fontSize: 12 }}>{backup.filename}</td>
                  <td style={{ padding: "12px 14px", fontSize: 12 }}>{formatBytes(backup.fileSizeBytes)}</td>
                  <td style={{ padding: "12px 14px", fontSize: 12 }}>{backup.createdAt ? new Date(backup.createdAt).toLocaleString() : "—"}</td>
                  <td style={{ padding: "12px 14px", fontFamily: "monospace", fontSize: 12 }}>{backup.checksumSha256 ? `${backup.checksumSha256.slice(0, 12)}…` : "—"}</td>
                  <td style={{ padding: "12px 14px", fontSize: 12 }}>{backup.storageProvider || "local"}</td>
                  <td style={{ padding: "12px 14px", fontSize: 12, color: badgeColor(backup.uploadStatus) }}>{backup.uploadStatus || "—"}</td>
                  <td style={{ padding: "12px 14px", fontSize: 12, color: badgeColor(backup.verifyStatus) }}>{backup.verifyStatus || "—"}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <button
                      data-testid={`button-verify-${backup.id}`}
                      onClick={() => verifyBackup(backup.id)}
                      style={{ background: "transparent", color: C.gold, border: `1px solid ${C.border}`, borderRadius: 8, padding: "6px 10px", cursor: "pointer" }}
                    >
                      Verify
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
