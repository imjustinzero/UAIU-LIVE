# UAIU.LIVE/X Backup & Disaster Recovery Runbook

## 1. Overview
UAIU.LIVE/X operates a production PostgreSQL-backed trading platform with institutional buyer, seller, settlement, payout, and admin workflows. The primary system of record is the production PostgreSQL database referenced by `DATABASE_URL`.

**Backup owners**
- Platform owner: UAIU Holdings Corp.
- Technical restore owner: designated platform operator or lead engineer
- Approval authority for production restore: platform owner or delegated incident commander

## 2. Backup Policy
- **Frequency:** daily automated backup plus on-demand manual backups from the admin panel
- **Retention:** 30 remote backups, 7 local backups
- **Storage:** S3-compatible object storage as primary off-site target; `/tmp/uaiu_backups` as local secondary working directory
- **Format:** plain SQL `pg_dump`
- **Metadata captured per backup:** filename, file size, SHA-256 checksum, upload status, storage path, provider, created_at, verify_status, verified_at

## 3. Recovery Point Objective (RPO)
Target RPO: **24 hours**
- In a restore scenario, the platform is expected to recover to the last successful backup within the prior 24-hour window.

## 4. Recovery Time Objective (RTO)
Target RTO: **4 hours**
- Measured from incident declaration to controlled resumption of trading.

## 5. Backup Metadata
Every backup must create a `backup_logs` row containing:
- filename
- file_size_bytes
- checksum_sha256
- storage_path
- storage_provider
- upload_status
- backup_type
- triggered_by
- error_message
- created_at
- verified_at
- verify_status

## 6. Restore Procedure

### Step 1 — Locate backup
Use the admin panel Backup & DR tab, or query directly:

```bash
psql "$DATABASE_URL" -c "SELECT id, filename, storage_provider, storage_path, checksum_sha256, created_at FROM backup_logs ORDER BY created_at DESC LIMIT 20;"
```

### Step 2 — Download backup from S3-compatible storage
AWS S3 example:

```bash
aws s3 cp s3://$S3_BACKUP_BUCKET/uaiu-backups/uaiu_YYYY-MM-DD_HH-MM-SS.sql ./restore.sql
```

Custom endpoint example:

```bash
aws --endpoint-url "$S3_BACKUP_ENDPOINT" s3 cp s3://$S3_BACKUP_BUCKET/uaiu-backups/uaiu_YYYY-MM-DD_HH-MM-SS.sql ./restore.sql
```

### Step 3 — Stop trading
Disable new trading activity before restore:

```bash
export TRADING_DISABLED=1
```

Restart the app with trading disabled if needed.

### Step 4 — Restore into clean database or clean schema
For full rebuilds, restore into a clean database. For managed environments, drop and recreate the target schema carefully.

Example clean schema reset:

```bash
psql "$DATABASE_URL" -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"
```

### Step 5 — Restore SQL dump
```bash
psql "$DATABASE_URL" < ./restore.sql
```

### Step 6 — Verify schema alignment
```bash
npm run db:push
```

### Step 7 — Smoke test critical paths
Test:
- auth endpoints
- exchange signin
- protected trading routes
- Stripe webhook route registration
- admin health and backup routes

Example checks:

```bash
curl -i https://uaiu.live/api/admin/health-check -H "X-Admin-Key: $ADMIN_SECRET_KEY"
curl -i https://uaiu.live/api/admin/backup/list -H "X-Admin-Key: $ADMIN_SECRET_KEY"
```

### Step 8 — Re-enable trading
```bash
unset TRADING_DISABLED
```

Restart the app if required.

## 7. Restore Owner
The designated platform operator or lead engineer is responsible for executing the restore. Production restore approval must come from the platform owner or delegated incident commander.

## 8. Verification Cadence
- **Weekly:** run `/api/admin/backup/verify/:id` against the latest backup
- **Monthly:** complete a full restore test into a non-production PostgreSQL instance

## 9. Restore-Test Checklist
1. Trigger a manual backup via the admin panel
2. Confirm the backup appears in the list with `upload_status=uploaded`
3. Click **Verify** and confirm `verify_status=ok`
4. Download the `.sql` file from S3-compatible storage
5. Restore it into a test PostgreSQL instance
6. Confirm row counts on key tables match production expectations
7. Confirm app boot succeeds against the restored database
8. Record test date, tester, and result in the runbook log below

## 10. Runbook Test Log

| Date | Tester | Result | Notes |
|---|---|---|---|
| YYYY-MM-DD | Name | Pass / Fail | Initial entry placeholder |

## 11. Incident Classification
Use **restore** when:
- production database corruption is confirmed
- destructive data loss occurred
- rollback is insufficient

Use **rollback** when:
- code deploy caused instability but data remains intact

Use **manual fix** when:
- issue is isolated, reversible, and lower risk than a full restore

## 12. Environment Variables Required
- `DATABASE_URL` — production PostgreSQL connection string
- `ADMIN_SECRET_KEY` — protects admin backup endpoints
- `S3_BACKUP_BUCKET` — object storage bucket name
- `AWS_ACCESS_KEY_ID` — access key for S3-compatible storage
- `AWS_SECRET_ACCESS_KEY` — secret key for S3-compatible storage
- `AWS_REGION` — region, default `us-east-1`
- `S3_BACKUP_ENDPOINT` — optional custom endpoint for R2, B2, MinIO, or other S3-compatible providers
- `TRADING_DISABLED` — emergency flag to suspend trading during restore or incident containment
