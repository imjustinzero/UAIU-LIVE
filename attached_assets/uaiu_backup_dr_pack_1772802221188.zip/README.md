UAIU Backup & DR Pack

This pack is a drop-in implementation kit for institutional-grade backup and disaster recovery.

Included:
- server/backup-storage.ts
- client/src/components/admin/BackupAdmin.tsx
- docs/BACKUP_ROLLBACK_RUNBOOK.md
- patches/SCHEMA_PATCH.md
- patches/CRON_PATCH.md
- patches/ROUTES_PATCH.md
- patches/ADMIN_PATCH.md
- patches/PACKAGE_PATCH.md

Notes:
- I could inspect the repo structure and existing Admin/cron/schema files, but I could not directly run your repo, install packages, push db changes, or restart your deployment from here.
- The patch instructions are written to fit the codebase I inspected.
