Install using package manager:
npm install @aws-sdk/client-s3 @aws-sdk/lib-storage

Expected package.json dependency additions:
- "@aws-sdk/client-s3"
- "@aws-sdk/lib-storage"
