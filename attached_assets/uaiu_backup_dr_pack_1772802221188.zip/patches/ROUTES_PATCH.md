Patch whichever server file currently owns admin ops backup routes.
Your spec says server/ops-routes.ts, but if backup trigger lives elsewhere in this repo, apply there.

Add imports:
- backupLogs from shared/schema
- eq, desc from drizzle-orm
- headS3Object, isS3Configured from ./backup-storage
- triggerDatabaseBackup from ./cron
- fs, crypto

Routes:

GET /api/admin/backup/list
- requireAdminHeader
- select latest 50 from backup_logs order by created_at desc
- return { backups, s3Configured: isS3Configured(), bucketName: process.env.S3_BACKUP_BUCKET || null }

POST /api/admin/backup/trigger
- requireAdminHeader
- call triggerDatabaseBackup("admin", "manual")
- return full metadata

POST /api/admin/backup/verify/:id
- requireAdminHeader
- look up backup row
- if s3 provider and configured:
  - head object
  - compare size
  - update verified_at and verify_status
- if local:
  - check file exists
  - recompute checksum
  - update verified_at and verify_status
- return { id, verifyStatus, details }

Every failure path should return sanitized errors, not raw internals.
