Apply to shared/schema.ts

1. Extend imports:
- add `uuid` to pg-core imports if available in your setup, otherwise use varchar with gen_random_uuid()
- add backupLogs table
- add createInsertSchema + types

Suggested table:

export const backupLogs = pgTable("backup_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  fileSizeBytes: integer("file_size_bytes"),
  checksumSha256: text("checksum_sha256"),
  storagePath: text("storage_path"),
  storageProvider: text("storage_provider").notNull().default("local"),
  uploadStatus: text("upload_status").notNull().default("pending"),
  backupType: text("backup_type").notNull().default("scheduled"),
  triggeredBy: text("triggered_by").notNull().default("cron"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  verifiedAt: timestamp("verified_at"),
  verifyStatus: text("verify_status"),
});

export const insertBackupLogSchema = createInsertSchema(backupLogs).omit({
  id: true,
  createdAt: true,
});

export type BackupLog = typeof backupLogs.$inferSelect;
export type InsertBackupLog = z.infer<typeof insertBackupLogSchema>;
