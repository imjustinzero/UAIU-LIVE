Patch server/cron.ts

Add:
- imports: fs, path, crypto, child_process.execFile or spawn
- import backupLogs from schema
- import db
- import uploadToS3, isS3Configured, pruneS3Backups from ./backup-storage

Implement:
- export async function triggerDatabaseBackup(triggeredBy = "cron", backupType = "scheduled")
- write dump to /tmp/uaiu_backups/uaiu_${timestamp}.sql
- compute sha256 and file size
- insert backup_logs row
- upload to S3 when configured
- update upload status / error
- prune local to 7 and remote to 30
- return { success, file, checksumSha256, fileSizeBytes, s3Key, logId }

Then:
- schedule first backup 5 minutes after startup
- schedule every 24 hours after that
- keep existing escrow watchdog logic unchanged
