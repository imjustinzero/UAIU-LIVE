Patch client/src/pages/Admin.tsx

1. import BackupAdmin:
import BackupAdmin from "@/components/admin/BackupAdmin";

2. extend activeTab union:
'listings' | 'webhooks' | 'health' | 'backup'

3. add tab button:
{ id: 'backup', label: 'Backup & DR', count: null }

4. render:
{activeTab === 'backup' && <BackupAdmin adminKey={adminKey} />}

No other auth changes needed because Admin already stores and passes the admin key.
