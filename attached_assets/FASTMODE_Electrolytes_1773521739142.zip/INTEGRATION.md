# FASTMODE — Electrolyte Tracker Integration Guide

## Files to Add
- ElectrolyteTracker.jsx → copy into /src/

---

## Step 1 — Import the component
At the top of App.jsx, add:

  import ElectrolyteTracker from './ElectrolyteTracker'

---

## Step 2 — Add the nav tab
Find your `tabs` array in App.jsx and add the electrolytes tab:

  const tabs = [
    { id: "home", icon: "home", label: "Home" },
    { id: "timer", icon: "timer", label: "Fast" },
    { id: "food", icon: "food", label: "Food" },
    { id: "electrolytes", icon: "zap", label: "Electro" },   // ← ADD THIS
    ...(profile.useBlueprint ? [{ id: "blueprint", icon: "blueprint", label: "Blueprint" }] : []),
    { id: "progress", icon: "chart", label: "Progress" },
  ];

---

## Step 3 — Add the Zap icon
In your Ic component's icons object, add:

  zap: <><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></>,

---

## Step 4 — Add the render block
In the app render section, add alongside other screens:

  {tab === "electrolytes" && (
    <ElectrolyteTracker
      profile={profile}
      weightLogs={weightLogs}
      fastState={fastState}
    />
  )}

---

## Step 5 — Done!
That's it. The module uses its own localStorage keys (fm_elec_logs, fm_elec_wtrack)
so it won't conflict with any existing data.

---

## What's Included

### Targets (auto-calculated)
- Sodium, Potassium, Magnesium targets scaled to body weight using NIH DRIs
- Fasting multipliers kick in automatically when fasting is active:
  - 0-24h fast: +40% Na, +30% K, +20% Mg
  - 24-48h fast: +70% Na, +50% K, +35% Mg
  - 48-72h fast: +100% Na, +80% K, +50% Mg
  - 72h+ fast: +120% Na, +100% K, +60% Mg

### Weight Tracking
- Targets recalculate every time a new weight is logged in Progress tab
- User selects Daily / Weekly / Monthly tracking frequency
- Banner reminds user when weight update is overdue

### Features
- Today tab: Live progress bars for all 3 electrolytes + quick-add buttons
- Guide tab: Exact dosing amounts, timing, Amazon/Sprouts/Walmart products, electrolyte drink recipes
- History tab: 7-day compliance grid, full log history
- Fasting mode banner with hour-by-hour context
- Safety warnings (potassium 99mg cap, extended fast guidance)
