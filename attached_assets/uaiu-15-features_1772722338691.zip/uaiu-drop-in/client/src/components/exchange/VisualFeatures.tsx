import { useEffect, useRef, useState } from "react";

// ── 3D GLOBE ─────────────────────────────────────────────
interface GlobePin {
  name: string;
  lat: number;
  lng: number;
  tonnes: number;
  standard: string;
}

const GLOBE_PINS: GlobePin[] = [
  { name: "Tonga Blue Carbon", lat: -21.2, lng: -175.2, tonnes: 280000, standard: "VCS" },
  { name: "Antigua Coastal Resilience", lat: 17.1, lng: -61.8, tonnes: 95000, standard: "Gold Standard" },
  { name: "Roatan Reef Restoration", lat: 16.3, lng: -86.5, tonnes: 180000, standard: "VCS REDD++" },
  { name: "East Delta Dena Zone", lat: 34.2, lng: -118.1, tonnes: 25000, standard: "CAR" },
  { name: "Tuskegee Regenerative City", lat: 32.4, lng: -85.7, tonnes: 40000, standard: "ACR" },
  { name: "Woodland Farm Aggregation", lat: 38.7, lng: -121.8, tonnes: 15000, standard: "CAR" },
];

export function Globe3D({ isDark = true, onPinClick }: {
  isDark?: boolean;
  onPinClick?: (pin: GlobePin) => void;
}) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [tooltip, setTooltip] = useState<{ pin: GlobePin; x: number; y: number } | null>(null);
  const [loaded, setLoaded] = useState(false);
  const sceneRef = useRef<any>(null);

  useEffect(() => {
    if (!mountRef.current) return;
    const el = mountRef.current;
    let animId: number;
    let THREE: any;

    const init = async () => {
      THREE = (window as any).THREE;
      if (!THREE) {
        // Load Three.js dynamically
        await new Promise<void>((resolve, reject) => {
          const s = document.createElement('script');
          s.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
          s.onload = () => resolve();
          s.onerror = reject;
          document.head.appendChild(s);
        });
        THREE = (window as any).THREE;
      }

      const W = el.clientWidth || 480;
      const H = Math.min(W, 480);

      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(W, H);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      el.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, W / H, 0.1, 100);
      camera.position.z = 2.8;

      // Globe sphere
      const geo = new THREE.SphereGeometry(1, 64, 64);
      const mat = new THREE.MeshPhongMaterial({
        color: 0x0d1b3e,
        emissive: 0x061020,
        shininess: 40,
        transparent: true,
        opacity: 0.95
      });
      const globe = new THREE.Mesh(geo, mat);
      scene.add(globe);

      // Wireframe overlay
      const wGeo = new THREE.SphereGeometry(1.001, 24, 24);
      const wMat = new THREE.MeshBasicMaterial({
        color: 0x1a3060, wireframe: true, transparent: true, opacity: 0.15
      });
      scene.add(new THREE.Mesh(wGeo, wMat));

      // Atmosphere glow
      const atmGeo = new THREE.SphereGeometry(1.08, 32, 32);
      const atmMat = new THREE.MeshBasicMaterial({
        color: 0x1a4080, transparent: true, opacity: 0.08, side: THREE.BackSide
      });
      scene.add(new THREE.Mesh(atmGeo, atmMat));

      // Lighting
      scene.add(new THREE.AmbientLight(0x334466, 1.2));
      const dirLight = new THREE.DirectionalLight(0xffffff, 1.5);
      dirLight.position.set(3, 2, 3);
      scene.add(dirLight);
      const goldLight = new THREE.PointLight(0xD4A843, 0.6, 10);
      goldLight.position.set(-2, 1, 2);
      scene.add(goldLight);

      // Convert lat/lng to 3D position
      const latLngTo3D = (lat: number, lng: number, r = 1.02) => {
        const phi = (90 - lat) * (Math.PI / 180);
        const theta = (lng + 180) * (Math.PI / 180);
        return new THREE.Vector3(
          -r * Math.sin(phi) * Math.cos(theta),
          r * Math.cos(phi),
          r * Math.sin(phi) * Math.sin(theta)
        );
      };

      // Add pins
      const pinMeshes: { mesh: THREE.Mesh; pin: GlobePin }[] = [];
      GLOBE_PINS.forEach(pin => {
        const pos = latLngTo3D(pin.lat, pin.lng);
        // Glowing sphere pin
        const pGeo = new THREE.SphereGeometry(0.025, 12, 12);
        const pMat = new THREE.MeshBasicMaterial({ color: 0xD4A843 });
        const pMesh = new THREE.Mesh(pGeo, pMat);
        pMesh.position.copy(pos);
        scene.add(pMesh);
        // Pulse ring
        const rGeo = new THREE.RingGeometry(0.03, 0.045, 16);
        const rMat = new THREE.MeshBasicMaterial({
          color: 0xD4A843, transparent: true, opacity: 0.4, side: THREE.DoubleSide
        });
        const ring = new THREE.Mesh(rGeo, rMat);
        ring.position.copy(pos);
        ring.lookAt(new THREE.Vector3(0,0,0));
        scene.add(ring);
        pinMeshes.push({ mesh: pMesh, pin });
      });

      sceneRef.current = { renderer, scene, camera, globe, pinMeshes };

      // Mouse interaction
      const raycaster = new THREE.Raycaster();
      const mouse = new THREE.Vector2();
      let isDragging = false;
      let prevMouse = { x: 0, y: 0 };

      renderer.domElement.addEventListener('mousemove', (e: MouseEvent) => {
        const rect = renderer.domElement.getBoundingClientRect();
        mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

        if (isDragging) {
          const dx = e.clientX - prevMouse.x;
          const dy = e.clientY - prevMouse.y;
          globe.rotation.y += dx * 0.005;
          globe.rotation.x += dy * 0.005;
          prevMouse = { x: e.clientX, y: e.clientY };
        }

        // Hover detection
        raycaster.setFromCamera(mouse, camera);
        const hits = raycaster.intersectObjects(pinMeshes.map(p => p.mesh));
        if (hits.length > 0) {
          const found = pinMeshes.find(p => p.mesh === hits[0].object);
          if (found) {
            setTooltip({ pin: found.pin, x: e.clientX - rect.left, y: e.clientY - rect.top });
            renderer.domElement.style.cursor = 'pointer';
          }
        } else {
          setTooltip(null);
          renderer.domElement.style.cursor = isDragging ? 'grabbing' : 'grab';
        }
      });

      renderer.domElement.addEventListener('mousedown', (e: MouseEvent) => {
        isDragging = true;
        prevMouse = { x: e.clientX, y: e.clientY };
        renderer.domElement.style.cursor = 'grabbing';
      });
      renderer.domElement.addEventListener('mouseup', () => {
        isDragging = false;
        renderer.domElement.style.cursor = 'grab';
      });
      renderer.domElement.addEventListener('click', () => {
        if (tooltip && onPinClick) onPinClick(tooltip.pin);
      });

      let autoRotate = true;
      renderer.domElement.addEventListener('mouseenter', () => { autoRotate = false; });
      renderer.domElement.addEventListener('mouseleave', () => { autoRotate = true; isDragging = false; });

      // Animate
      let t = 0;
      const animate = () => {
        animId = requestAnimationFrame(animate);
        t += 0.016;
        if (autoRotate) globe.rotation.y += 0.003;
        // Pulse pins
        pinMeshes.forEach(({ mesh }, i) => {
          const s = 1 + 0.2 * Math.sin(t * 2 + i);
          mesh.scale.setScalar(s);
        });
        renderer.render(scene, camera);
      };
      animate();
      setLoaded(true);
    };

    init().catch(() => setLoaded(false));
    return () => {
      cancelAnimationFrame(animId);
      if (sceneRef.current?.renderer) {
        sceneRef.current.renderer.dispose();
        if (el.contains(sceneRef.current.renderer.domElement)) {
          el.removeChild(sceneRef.current.renderer.domElement);
        }
      }
    };
  }, []);

  return (
    <div style={{ position:'relative', display:'inline-block' }}>
      <div ref={mountRef} style={{
        width:'clamp(280px,40vw,480px)',
        height:'clamp(280px,40vw,480px)',
        cursor:'grab', borderRadius:'50%',
        boxShadow:'0 0 60px rgba(212,168,67,0.15), 0 0 120px rgba(13,27,62,0.8)'
      }} />
      {!loaded && (
        <div style={{
          position:'absolute',inset:0,display:'flex',alignItems:'center',
          justifyContent:'center',borderRadius:'50%',
          background:'rgba(13,27,62,0.8)'
        }}>
          <span style={{color:'#D4A843',fontSize:'12px',fontFamily:'JetBrains Mono,monospace'}}>
            LOADING GLOBE...
          </span>
        </div>
      )}
      {tooltip && (
        <div style={{
          position:'absolute',left:tooltip.x+12,top:tooltip.y-10,
          background:'rgba(13,27,62,0.95)',border:'1px solid rgba(212,168,67,0.4)',
          borderRadius:'8px',padding:'10px 14px',pointerEvents:'none',zIndex:10,
          minWidth:'180px'
        }}>
          <p style={{margin:'0 0 4px',fontWeight:700,fontSize:'12px',color:'#D4A843'}}>
            {tooltip.pin.name}
          </p>
          <p style={{margin:'0 0 2px',fontSize:'11px',color:'rgba(255,255,255,0.7)'}}>
            {tooltip.pin.tonnes.toLocaleString()} tonnes
          </p>
          <p style={{margin:0,fontSize:'10px',color:'rgba(255,255,255,0.4)'}}>
            {tooltip.pin.standard}
          </p>
        </div>
      )}
    </div>
  );
}

// ── DARK/LIGHT MODE HOOK ───────────────────────────────────
export function useDarkMode() {
  const [isDark, setIsDark] = useState(true);

  const toggle = () => setIsDark(prev => !prev);

  return { isDark, toggle };
}

export function DarkModeToggle({ isDark, onToggle }: { isDark: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
      style={{
        padding:'6px 10px',borderRadius:'8px',border:'1px solid rgba(212,168,67,0.3)',
        background:'transparent',cursor:'pointer',fontSize:'16px',
        lineHeight:1,transition:'all 0.2s'
      }}
    >
      {isDark ? '☀️' : '🌙'}
    </button>
  );
}

// ── MOBILE NAV HAMBURGER ───────────────────────────────────
interface MobileNavProps {
  links: { label: string; href: string }[];
  isDark?: boolean;
}

export function MobileNav({ links, isDark = true }: MobileNavProps) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        style={{
          display:'none', // shown via CSS media query in parent
          padding:'8px',borderRadius:'8px',border:'1px solid rgba(212,168,67,0.3)',
          background:'transparent',cursor:'pointer',color:'#D4A843',fontSize:'20px'
        }}
        className="hamburger-btn"
      >
        {open ? '✕' : '☰'}
      </button>

      {open && (
        <div style={{
          position:'fixed',inset:0,zIndex:999,
          background: isDark ? 'rgba(6,6,12,0.98)' : 'rgba(255,255,255,0.98)',
          display:'flex',flexDirection:'column',alignItems:'center',
          justifyContent:'center',gap:'8px'
        }}>
          <button onClick={() => setOpen(false)} style={{
            position:'absolute',top:'20px',right:'20px',
            padding:'8px',background:'transparent',border:'none',
            color: isDark ? '#ffffff' : '#0d1b3e',fontSize:'24px',cursor:'pointer'
          }}>✕</button>
          {links.map((link, i) => (
            <a key={i} href={link.href} onClick={() => setOpen(false)} style={{
              padding:'16px 40px',fontSize:'18px',fontWeight:700,
              color: isDark ? '#ffffff' : '#0d1b3e',
              textDecoration:'none',letterSpacing:'0.05em',
              borderBottom:`1px solid rgba(212,168,67,0.1)`,
              width:'80%',textAlign:'center'
            }}>
              {link.label}
            </a>
          ))}
          <a href="#rfq" onClick={() => setOpen(false)} style={{
            marginTop:'16px',padding:'14px 40px',borderRadius:'10px',
            background:'#D4A843',color:'#0a0a0f',fontWeight:700,
            fontSize:'16px',textDecoration:'none',letterSpacing:'0.05em'
          }}>
            Submit RFQ →
          </a>
        </div>
      )}
    </>
  );
}

// ── VISION PROJECT VERIFICATION ────────────────────────────
interface VisionVerificationProps {
  onReport: (report: string) => void;
  isDark?: boolean;
}

export function VisionVerification({ onReport, isDark = true }: VisionVerificationProps) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState('');

  const handleFile = (f: File) => {
    setFile(f);
    const reader = new FileReader();
    reader.onload = e => setPreview(e.target?.result as string);
    reader.readAsDataURL(f);
  };

  const analyze = async () => {
    if (!file || !preview) return;
    setLoading(true);
    try {
      const base64 = preview.split(',')[1];
      const res = await fetch('/api/ai/vision-verify', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ image: base64, mediaType: file.type }),
        signal: AbortSignal.timeout(20000)
      });
      if (res.ok) {
        const data = await res.json();
        setReport(data.report || MOCK_REPORT);
        onReport(data.report || MOCK_REPORT);
      } else {
        setReport(MOCK_REPORT);
        onReport(MOCK_REPORT);
      }
    } catch {
      setReport(MOCK_REPORT);
      onReport(MOCK_REPORT);
    } finally {
      setLoading(false);
    }
  };

  const MOCK_REPORT = `PRELIMINARY PROJECT VERIFICATION REPORT
Generated by UAIU AI Vision System

LOCATION ASSESSMENT: Image appears to show agricultural/natural land with carbon sequestration potential. Vegetation coverage estimated at 60-80%.

CARBON SEQUESTRATION ESTIMATE: Based on visible land characteristics, estimated sequestration potential of 0.4-0.8 tonnes CO₂/acre/year. Formal verification recommended under VCS or CAR protocol.

RECOMMENDED STANDARD: VCS (Verified Carbon Standard) or CAR (Climate Action Reserve) based on land type.

NEXT STEPS: Submit for formal third-party verification. UAIU partners with Indigo Ag and Nori for streamlined verification. Estimated time to first credit issuance: 6-12 months.

NOTE: This is a preliminary AI assessment only and does not constitute formal carbon credit verification.`;

  const inputStyle: React.CSSProperties = {
    border:'2px dashed rgba(212,168,67,0.3)',borderRadius:'10px',
    padding:'20px',textAlign:'center',cursor:'pointer',
    background: isDark ? 'rgba(0,0,0,0.2)' : 'rgba(255,255,255,0.5)',
    transition:'border-color 0.2s'
  };

  return (
    <div style={{marginTop:'16px'}}>
      <p style={{margin:'0 0 10px',fontSize:'12px',fontWeight:700,
        letterSpacing:'0.08em',textTransform:'uppercase',
        color:'rgba(212,168,67,0.7)'}}>
        AI PROJECT VERIFICATION (Optional)
      </p>
      <p style={{margin:'0 0 12px',fontSize:'12px',
        color: isDark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)'}}>
        Upload a satellite image or project photo for an instant AI preliminary verification report.
      </p>

      {!preview ? (
        <label style={inputStyle}>
          <input type="file" accept="image/*" style={{display:'none'}}
            onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
          <p style={{fontSize:'24px',margin:'0 0 8px'}}>📸</p>
          <p style={{margin:0,fontSize:'13px',
            color: isDark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)'}}>
            Click to upload project image
          </p>
        </label>
      ) : (
        <div>
          <img src={preview} alt="Project" style={{
            width:'100%',maxHeight:'200px',objectFit:'cover',
            borderRadius:'8px',marginBottom:'10px'
          }} />
          <button onClick={analyze} disabled={loading} style={{
            width:'100%',padding:'10px',borderRadius:'8px',border:'none',
            background: loading ? 'rgba(212,168,67,0.3)' : '#D4A843',
            color:'#0a0a0f',fontWeight:700,fontSize:'13px',
            cursor:loading?'wait':'pointer'
          }}>
            {loading ? '⟳ Analyzing with AI...' : '✦ Analyze Project →'}
          </button>
        </div>
      )}

      {report && (
        <div style={{
          marginTop:'12px',padding:'16px',borderRadius:'8px',
          background: isDark ? 'rgba(212,168,67,0.05)' : 'rgba(212,168,67,0.08)',
          border:'1px solid rgba(212,168,67,0.2)',
          fontFamily:'JetBrains Mono,monospace',fontSize:'11px',lineHeight:1.8,
          color: isDark ? 'rgba(255,255,255,0.8)' : 'rgba(0,0,0,0.8)',
          whiteSpace:'pre-wrap',maxHeight:'200px',overflowY:'auto'
        }}>
          {report}
        </div>
      )}
    </div>
  );
}
