import { useState, useEffect } from "react";

// ── TYPES ─────────────────────────────────────────────────
interface TradeRecord {
  trade_id: string;
  side: string;
  standard: string;
  price_eur_per_tonne: number;
  volume_tonnes: number;
  gross_eur: number;
  fee_eur: number;
  net_eur: number;
  receipt_hash: string;
  verify_url: string;
  settlement: string;
  created_at?: string;
}

interface RetirementRecord {
  cert_id: string;
  trade_id: string;
  tonnes: number;
  beneficiary: string;
  period: string;
  receipt_hash: string;
  created_at?: string;
}

interface PortfolioDashboardProps {
  trades: TradeRecord[];
  retirements: RetirementRecord[];
  accountName?: string;
  annualTarget?: number;
  isDark?: boolean;
}

// ── PORTFOLIO DASHBOARD ───────────────────────────────────
export function PortfolioDashboard({
  trades, retirements, accountName = 'Your Account',
  annualTarget = 10000, isDark = true
}: PortfolioDashboardProps) {
  const totalTonnesBought = trades.filter(t=>t.side==='buy').reduce((s,t)=>s+t.volume_tonnes,0);
  const totalSpendEur = trades.reduce((s,t)=>s+t.gross_eur,0);
  const totalRetired = retirements.reduce((s,r)=>s+r.tonnes,0);
  const compliancePct = annualTarget > 0 ? Math.round((totalRetired/annualTarget)*100) : 0;
  const complianceColor = compliancePct >= 80 ? '#4ade80' : compliancePct >= 40 ? '#D4A843' : '#f87171';
  const complianceStatus = compliancePct >= 80 ? 'ON TRACK' : compliancePct >= 40 ? 'IN PROGRESS' : 'ACTION NEEDED';

  const bg = isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.04)';
  const cardBorder = '1px solid rgba(212,168,67,0.15)';

  const StatCard = ({ label, value, sub, color = '#D4A843' }: any) => (
    <div style={{background:bg,border:cardBorder,borderRadius:'12px',padding:'20px',textAlign:'center'}}>
      <p style={{margin:'0 0 4px',fontSize:'10px',fontWeight:700,letterSpacing:'0.1em',
        textTransform:'uppercase',color:'rgba(212,168,67,0.6)'}}>{label}</p>
      <p style={{margin:'0 0 2px',fontFamily:'JetBrains Mono,monospace',
        fontSize:'24px',fontWeight:700,color}}>{value}</p>
      {sub && <p style={{margin:0,fontSize:'11px',color:'rgba(255,255,255,0.4)'}}>{sub}</p>}
    </div>
  );

  return (
    <section id="dashboard" style={{
      padding:'clamp(60px,8vw,100px) clamp(20px,5vw,80px)',
      background: isDark ? '#0a0a0f' : '#f8f9fa'
    }}>
      <div style={{maxWidth:'1200px',margin:'0 auto'}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-end',
          marginBottom:'40px',flexWrap:'wrap',gap:'12px'}}>
          <div>
            <p style={{margin:'0 0 8px',fontSize:'11px',fontWeight:700,letterSpacing:'0.15em',
              textTransform:'uppercase',color:'#D4A843'}}>◈ PORTFOLIO</p>
            <h2 style={{margin:0,fontSize:'clamp(24px,4vw,36px)',fontWeight:800,
              color: isDark ? '#ffffff' : '#0d1b3e',letterSpacing:'-0.02em'}}>
              {accountName} Dashboard.
            </h2>
          </div>
          <button
            onClick={() => generatePDFReport(trades, retirements, accountName)}
            style={{
              padding:'10px 20px',borderRadius:'10px',
              border:'1px solid rgba(212,168,67,0.3)',
              background:'rgba(212,168,67,0.1)',color:'#D4A843',
              fontSize:'13px',fontWeight:600,cursor:'pointer',letterSpacing:'0.05em'
            }}>
            ↓ Download Compliance Report
          </button>
        </div>

        {/* Stats Grid */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',
          gap:'16px',marginBottom:'32px'}}>
          <StatCard label="Carbon Position" value={totalTonnesBought.toLocaleString()} sub="tonnes bought" />
          <StatCard label="Total Spend" value={`€${(totalSpendEur/1000).toFixed(0)}K`} sub="gross EUR" />
          <StatCard label="Tonnes Retired" value={totalRetired.toLocaleString()} sub="permanently cancelled" color="#4ade80" />
          <StatCard label="Trades" value={trades.length} sub="executed" />
          <StatCard label="Certificates" value={retirements.length} sub="issued" color="#60a5fa" />
          <div style={{background:bg,border:`1px solid ${complianceColor}44`,
            borderRadius:'12px',padding:'20px',textAlign:'center'}}>
            <p style={{margin:'0 0 4px',fontSize:'10px',fontWeight:700,letterSpacing:'0.1em',
              textTransform:'uppercase',color:complianceColor+'99'}}>EU ETS STATUS</p>
            <p style={{margin:'0 0 2px',fontFamily:'JetBrains Mono,monospace',
              fontSize:'24px',fontWeight:700,color:complianceColor}}>{compliancePct}%</p>
            <p style={{margin:0,fontSize:'11px',color:complianceColor,fontWeight:700}}>{complianceStatus}</p>
          </div>
        </div>

        {/* Compliance Progress Bar */}
        <div style={{background:bg,border:cardBorder,borderRadius:'12px',
          padding:'20px',marginBottom:'24px'}}>
          <div style={{display:'flex',justifyContent:'space-between',marginBottom:'8px'}}>
            <span style={{fontSize:'12px',fontWeight:700,color:'rgba(212,168,67,0.8)',
              letterSpacing:'0.05em'}}>ANNUAL COMPLIANCE PROGRESS</span>
            <span style={{fontFamily:'JetBrains Mono,monospace',fontSize:'12px',
              color: isDark ? '#ffffff' : '#0d1b3e'}}>
              {totalRetired.toLocaleString()} / {annualTarget.toLocaleString()} tonnes
            </span>
          </div>
          <div style={{height:'10px',background:'rgba(255,255,255,0.1)',borderRadius:'5px',overflow:'hidden'}}>
            <div style={{height:'100%',width:`${Math.min(compliancePct,100)}%`,
              background:`linear-gradient(90deg,${complianceColor},${complianceColor}88)`,
              borderRadius:'5px',transition:'width 0.5s ease'}} />
          </div>
        </div>

        {/* Recent Trades Table */}
        {trades.length > 0 && (
          <div style={{background:bg,border:cardBorder,borderRadius:'12px',
            padding:'20px',marginBottom:'16px',overflowX:'auto'}}>
            <h3 style={{margin:'0 0 16px',fontSize:'13px',fontWeight:700,
              letterSpacing:'0.08em',textTransform:'uppercase',color:'rgba(212,168,67,0.8)'}}>
              RECENT TRADES
            </h3>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:'12px'}}>
              <thead>
                <tr>
                  {['Trade ID','Side','Standard','Volume','Price','Gross EUR','Receipt'].map(h => (
                    <th key={h} style={{padding:'6px 12px',textAlign:'left',fontWeight:700,
                      letterSpacing:'0.06em',fontSize:'10px',textTransform:'uppercase',
                      color:'rgba(212,168,67,0.6)',borderBottom:'1px solid rgba(212,168,67,0.15)'}}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {trades.slice(0,10).map((t,i) => (
                  <tr key={i}>
                    <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono,monospace',
                      fontSize:'11px',color:'#D4A843'}}>{t.trade_id}</td>
                    <td style={{padding:'8px 12px',fontWeight:700,
                      color:t.side==='buy'?'#4ade80':'#f87171'}}>{t.side.toUpperCase()}</td>
                    <td style={{padding:'8px 12px',color: isDark?'rgba(255,255,255,0.7)':'rgba(0,0,0,0.7)'}}>{t.standard}</td>
                    <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono,monospace',
                      color: isDark?'#ffffff':'#0d1b3e'}}>{t.volume_tonnes.toLocaleString()}t</td>
                    <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono,monospace',
                      color: isDark?'#ffffff':'#0d1b3e'}}>€{t.price_eur_per_tonne.toFixed(2)}</td>
                    <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono,monospace',
                      color: isDark?'#ffffff':'#0d1b3e'}}>€{t.gross_eur.toLocaleString()}</td>
                    <td style={{padding:'8px 12px',fontFamily:'JetBrains Mono,monospace',
                      fontSize:'10px',color:'rgba(255,255,255,0.3)'}}>
                      {t.receipt_hash.slice(0,12)}...
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {trades.length === 0 && (
          <div style={{textAlign:'center',padding:'60px',
            border:'2px dashed rgba(212,168,67,0.2)',borderRadius:'12px'}}>
            <p style={{fontSize:'32px',margin:'0 0 12px'}}>📊</p>
            <p style={{color:'rgba(255,255,255,0.3)',margin:0}}>
              No trades yet. Execute your first trade to see your dashboard.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

// ── PDF COMPLIANCE REPORT ─────────────────────────────────
export async function generatePDFReport(
  trades: TradeRecord[],
  retirements: RetirementRecord[],
  companyName: string
) {
  // Dynamic import of jsPDF
  try {
    const { jsPDF } = await import('jspdf');
    const doc = new jsPDF({ orientation:'portrait', unit:'mm', format:'a4' });
    const now = new Date();
    const W = 210; const M = 20;

    // Header bar
    doc.setFillColor(13, 27, 62);
    doc.rect(0, 0, W, 40, 'F');
    doc.setTextColor(212, 168, 67);
    doc.setFontSize(18);
    doc.setFont('helvetica','bold');
    doc.text('UAIU HOLDINGS CORP', M, 16);
    doc.setFontSize(11);
    doc.setTextColor(200, 200, 200);
    doc.text('Carbon Credit Compliance Report', M, 24);
    doc.text(`Generated: ${now.toLocaleDateString()} ${now.toLocaleTimeString()}`, M, 31);

    // Company info
    doc.setTextColor(0,0,0);
    doc.setFontSize(13);
    doc.setFont('helvetica','bold');
    doc.text(`Account: ${companyName}`, M, 55);
    doc.setFont('helvetica','normal');
    doc.setFontSize(10);
    doc.text(`Reporting Period: ${now.getFullYear()} · Platform: uaiu.live/x`, M, 62);

    // Summary stats
    const totalTonnes = trades.reduce((s,t)=>s+t.volume_tonnes,0);
    const totalSpend = trades.reduce((s,t)=>s+t.gross_eur,0);
    const totalRetired = retirements.reduce((s,r)=>s+r.tonnes,0);

    doc.setFillColor(255, 248, 225);
    doc.rect(M, 70, W-M*2, 28, 'F');
    doc.setFontSize(10);
    doc.setFont('helvetica','bold');
    doc.setTextColor(13,27,62);
    doc.text(`Total Tonnes Purchased: ${totalTonnes.toLocaleString()} t`, M+5, 82);
    doc.text(`Total Spend: €${totalSpend.toLocaleString()}`, M+65, 82);
    doc.text(`Tonnes Retired: ${totalRetired.toLocaleString()} t`, M+125, 82);
    doc.text(`Trades Executed: ${trades.length}`, M+5, 92);
    doc.text(`Retirement Certificates: ${retirements.length}`, M+65, 92);
    doc.text(`Exchange: UAIU.LIVE/X`, M+125, 92);

    // Trades table header
    let y = 112;
    doc.setFillColor(13,27,62);
    doc.rect(M, y, W-M*2, 8, 'F');
    doc.setTextColor(212,168,67);
    doc.setFontSize(8);
    doc.setFont('helvetica','bold');
    doc.text('TRADE ID', M+2, y+5.5);
    doc.text('SIDE', M+38, y+5.5);
    doc.text('STANDARD', M+50, y+5.5);
    doc.text('VOLUME (t)', M+85, y+5.5);
    doc.text('PRICE €/t', M+112, y+5.5);
    doc.text('GROSS €', M+133, y+5.5);
    doc.text('SHA-256 (partial)', M+155, y+5.5);
    y += 8;

    doc.setFont('helvetica','normal');
    doc.setTextColor(0,0,0);
    trades.slice(0,20).forEach((t,i) => {
      if (y > 270) { doc.addPage(); y = 20; }
      doc.setFillColor(i%2===0 ? 248 : 255, i%2===0 ? 249 : 255, i%2===0 ? 250 : 255);
      doc.rect(M, y, W-M*2, 7, 'F');
      doc.setFontSize(7.5);
      doc.text(t.trade_id, M+2, y+5);
      doc.setTextColor(t.side==='buy'?0:180, t.side==='buy'?150:0, 0);
      doc.text(t.side.toUpperCase(), M+38, y+5);
      doc.setTextColor(0,0,0);
      doc.text(t.standard, M+50, y+5);
      doc.text(t.volume_tonnes.toLocaleString(), M+85, y+5);
      doc.text(`€${t.price_eur_per_tonne.toFixed(2)}`, M+112, y+5);
      doc.text(`€${t.gross_eur.toLocaleString()}`, M+133, y+5);
      doc.text(t.receipt_hash.slice(0,16)+'...', M+155, y+5);
      y += 7;
    });

    // Retirements
    if (retirements.length > 0) {
      y += 10;
      if (y > 260) { doc.addPage(); y = 20; }
      doc.setFont('helvetica','bold');
      doc.setFontSize(11);
      doc.setTextColor(13,27,62);
      doc.text('RETIREMENT CERTIFICATES', M, y);
      y += 8;

      doc.setFillColor(13,27,62);
      doc.rect(M, y, W-M*2, 8, 'F');
      doc.setTextColor(212,168,67);
      doc.setFontSize(8);
      doc.text('CERT ID', M+2, y+5.5);
      doc.text('TRADE ID', M+30, y+5.5);
      doc.text('TONNES', M+70, y+5.5);
      doc.text('BENEFICIARY', M+90, y+5.5);
      doc.text('PERIOD', M+140, y+5.5);
      doc.text('SHA-256', M+160, y+5.5);
      y += 8;

      doc.setFont('helvetica','normal');
      doc.setTextColor(0,0,0);
      retirements.forEach((r,i) => {
        if (y > 270) { doc.addPage(); y = 20; }
        doc.setFillColor(i%2===0?248:255,i%2===0?249:255,i%2===0?250:255);
        doc.rect(M, y, W-M*2, 7, 'F');
        doc.setFontSize(7.5);
        doc.text(r.cert_id, M+2, y+5);
        doc.text(r.trade_id, M+30, y+5);
        doc.text(r.tonnes.toLocaleString(), M+70, y+5);
        doc.text(r.beneficiary.slice(0,20), M+90, y+5);
        doc.text(r.period, M+140, y+5);
        doc.text(r.receipt_hash.slice(0,14)+'...', M+160, y+5);
        y += 7;
      });
    }

    // Footer
    const pages = doc.getNumberOfPages();
    for (let i = 1; i <= pages; i++) {
      doc.setPage(i);
      doc.setFillColor(13,27,62);
      doc.rect(0, 285, W, 12, 'F');
      doc.setTextColor(150,150,150);
      doc.setFontSize(7);
      doc.text(`UAIU Holdings Corp · uaiu.live/x · info@uaiu.live · Wyoming Corporation · Page ${i} of ${pages}`, M, 292);
    }

    doc.save(`UAIU-Compliance-Report-${now.getFullYear()}-${companyName.replace(/\s/g,'-')}.pdf`);
  } catch (e) {
    console.error('PDF generation failed:', e);
    alert('PDF generation requires jspdf. Run: npm install jspdf in your Replit shell, then try again.');
  }
}

// ── MULTI-SIG COMPLIANCE APPROVAL ─────────────────────────
interface MultiSigProps {
  tradeId: string;
  receiptHash: string;
  onApproved: (approvalToken: string) => void;
  onSkip: () => void;
  isDark?: boolean;
}

export function MultiSigApproval({ tradeId, receiptHash, onApproved, onSkip, isDark = true }: MultiSigProps) {
  const [email, setEmail] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [token] = useState(() =>
    Array.from(crypto.getRandomValues(new Uint8Array(16)))
      .map(b => b.toString(16).padStart(2,'0')).join('')
  );

  const handleSend = async () => {
    if (!email.trim()) return;
    setSending(true);
    try {
      await fetch('/api/exchange/compliance-approval', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ email, tradeId, receiptHash, token,
          approveUrl: `https://uaiu.live/approve/${token}` })
      });
    } catch {}
    setSent(true);
    setSending(false);
  };

  const handleApproveNow = () => {
    onApproved(token);
  };

  const overlay: React.CSSProperties = {
    position:'fixed',inset:0,background:'rgba(0,0,0,0.85)',
    display:'flex',alignItems:'center',justifyContent:'center',
    zIndex:1100,padding:'20px'
  };
  const modal: React.CSSProperties = {
    background: isDark ? '#0d1b2e' : '#ffffff',
    border:'1px solid rgba(212,168,67,0.3)',
    borderRadius:'16px',padding:'32px',maxWidth:'480px',width:'100%'
  };
  const inputStyle: React.CSSProperties = {
    width:'100%',padding:'10px 14px',borderRadius:'8px',
    border:'1px solid rgba(212,168,67,0.2)',
    background: isDark ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.8)',
    color: isDark ? '#ffffff' : '#0d1b3e',
    fontSize:'14px',boxSizing:'border-box',fontFamily:'inherit'
  };

  return (
    <div style={overlay}>
      <div style={modal}>
        <p style={{margin:'0 0 4px',fontSize:'11px',fontWeight:700,letterSpacing:'0.15em',
          textTransform:'uppercase',color:'#D4A843'}}>◈ COMPLIANCE APPROVAL</p>
        <h3 style={{margin:'0 0 8px',fontSize:'20px',fontWeight:800,
          color: isDark ? '#ffffff' : '#0d1b3e'}}>
          Pending Compliance Approval
        </h3>
        <p style={{margin:'0 0 20px',fontSize:'13px',
          color: isDark ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.6)'}}>
          Trade <strong style={{fontFamily:'JetBrains Mono,monospace',color:'#D4A843'}}>{tradeId}</strong> is awaiting compliance officer approval. Send an approval request or approve directly.
        </p>

        {!sent ? (
          <>
            <label style={{display:'block',marginBottom:'6px',fontSize:'11px',fontWeight:700,
              letterSpacing:'0.1em',textTransform:'uppercase',
              color: isDark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)'}}>
              Compliance Officer Email
            </label>
            <input value={email} onChange={e=>setEmail(e.target.value)}
              placeholder="compliance@yourcompany.com" style={inputStyle} />
            <div style={{display:'flex',gap:'10px',marginTop:'16px'}}>
              <button onClick={handleSend} disabled={sending || !email.trim()} style={{
                flex:1,padding:'12px',borderRadius:'8px',border:'none',
                background:'#D4A843',color:'#0a0a0f',fontWeight:700,
                fontSize:'13px',cursor:sending?'wait':'pointer'
              }}>
                {sending ? 'Sending...' : 'Send Approval Request →'}
              </button>
              <button onClick={handleApproveNow} style={{
                padding:'12px 16px',borderRadius:'8px',
                border:'1px solid rgba(212,168,67,0.3)',
                background:'transparent',color:'#D4A843',
                fontWeight:600,fontSize:'12px',cursor:'pointer'
              }}>
                Approve Now
              </button>
            </div>
            <button onClick={onSkip} style={{
              width:'100%',marginTop:'10px',padding:'8px',
              background:'transparent',border:'none',
              color:'rgba(255,255,255,0.3)',fontSize:'12px',cursor:'pointer'
            }}>
              Skip compliance step
            </button>
          </>
        ) : (
          <div style={{textAlign:'center',padding:'20px 0'}}>
            <p style={{fontSize:'32px',margin:'0 0 12px'}}>✉️</p>
            <p style={{fontSize:'14px',fontWeight:700,color:'#4ade80',margin:'0 0 8px'}}>
              Approval request sent to {email}
            </p>
            <p style={{fontSize:'12px',color:'rgba(255,255,255,0.5)',margin:'0 0 20px'}}>
              Approval URL: uaiu.live/approve/{token.slice(0,16)}...
            </p>
            <button onClick={handleApproveNow} style={{
              padding:'12px 32px',borderRadius:'8px',border:'none',
              background:'#D4A843',color:'#0a0a0f',fontWeight:700,
              fontSize:'13px',cursor:'pointer'
            }}>
              Approve Immediately →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
