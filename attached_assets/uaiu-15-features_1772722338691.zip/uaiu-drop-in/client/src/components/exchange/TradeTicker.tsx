import { useEffect, useRef, useState } from "react";

interface TickerTrade {
  id: string;
  side: string;
  standard: string;
  volume: number;
  price: number;
  ago: string;
}

const SEED_TRADES: TickerTrade[] = [
  { id:"UAIU-BUY-847291",side:"BUY",standard:"VCS",volume:2400,price:64.20,ago:"2m ago" },
  { id:"UAIU-SELL-193847",side:"SELL",standard:"CORSIA",volume:5000,price:58.80,ago:"7m ago" },
  { id:"UAIU-BUY-002841",side:"BUY",standard:"Gold Standard",volume:1200,price:71.50,ago:"12m ago" },
  { id:"UAIU-BUY-774920",side:"BUY",standard:"VCS",volume:8000,price:63.40,ago:"19m ago" },
  { id:"UAIU-SELL-009182",side:"SELL",standard:"ACR",volume:3500,price:61.90,ago:"24m ago" },
  { id:"UAIU-BUY-334718",side:"BUY",standard:"CAR",volume:750,price:66.00,ago:"31m ago" },
  { id:"UAIU-BUY-882910",side:"BUY",standard:"CORSIA",volume:12000,price:57.30,ago:"38m ago" },
  { id:"UAIU-SELL-447821",side:"SELL",standard:"VCS",volume:2000,price:64.80,ago:"45m ago" },
  { id:"UAIU-BUY-119283",side:"BUY",standard:"Gold Standard",volume:4400,price:70.20,ago:"52m ago" },
  { id:"UAIU-BUY-558019",side:"BUY",standard:"VCS",volume:9200,price:63.10,ago:"1h ago" },
  { id:"UAIU-SELL-223847",side:"SELL",standard:"ACR",volume:1800,price:62.50,ago:"1h ago" },
  { id:"UAIU-BUY-667291",side:"BUY",standard:"CAR",volume:6000,price:65.70,ago:"2h ago" },
];

function fmt(t: TickerTrade) {
  return `${t.id} · ${t.standard} · ${t.volume.toLocaleString()}t · €${t.price.toFixed(2)} · ${t.ago}`;
}

interface TradeTickerProps {
  newTrades?: TickerTrade[];
  isDark?: boolean;
}

export function TradeTicker({ newTrades = [], isDark = true }: TradeTickerProps) {
  const [trades, setTrades] = useState<TickerTrade[]>([...newTrades, ...SEED_TRADES]);
  const trackRef = useRef<HTMLDivElement>(null);
  const posRef = useRef(0);
  const rafRef = useRef<number>();

  useEffect(() => {
    if (newTrades.length > 0) {
      setTrades(prev => [...newTrades, ...prev].slice(0, 30));
    }
  }, [newTrades]);

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    const speed = 0.5;
    const tick = () => {
      posRef.current -= speed;
      const halfWidth = el.scrollWidth / 2;
      if (Math.abs(posRef.current) >= halfWidth) posRef.current = 0;
      el.style.transform = `translateX(${posRef.current}px)`;
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [trades]);

  const bg = isDark ? '#0a0a0f' : '#0d1b2e';
  const items = [...trades, ...trades];

  return (
    <div style={{
      width:'100%', overflow:'hidden', background:bg,
      borderBottom:'1px solid rgba(212,168,67,0.3)',
      padding:'6px 0', position:'relative'
    }}>
      <div style={{position:'absolute',left:0,top:0,bottom:0,width:'60px',
        background:`linear-gradient(to right, ${bg}, transparent)`,zIndex:2}} />
      <div style={{position:'absolute',right:0,top:0,bottom:0,width:'60px',
        background:`linear-gradient(to left, ${bg}, transparent)`,zIndex:2}} />
      <div ref={trackRef} style={{display:'flex',whiteSpace:'nowrap',willChange:'transform'}}>
        {items.map((t, i) => (
          <span key={i} style={{
            fontFamily:'JetBrains Mono,monospace', fontSize:'11px',
            color: t.side === 'BUY' ? '#4ade80' : '#f87171',
            marginRight:'48px', letterSpacing:'0.04em'
          }}>
            <span style={{color:'#D4A843',marginRight:'6px'}}>▸</span>
            {fmt(t)}
          </span>
        ))}
      </div>
    </div>
  );
}
