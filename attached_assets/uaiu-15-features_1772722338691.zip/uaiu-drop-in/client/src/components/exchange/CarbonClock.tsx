import { useEffect, useRef, useState } from "react";

export function CarbonClock() {
  const [tonnes, setTonnes] = useState(0);
  const startRef = useRef(Date.now());
  const rafRef = useRef<number>();
  const RATE = 1400;

  useEffect(() => {
    const tick = () => {
      const elapsed = (Date.now() - startRef.current) / 1000;
      setTonnes(Math.floor(elapsed * RATE));
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  return (
    <div style={{textAlign:'center',padding:'10px 0',borderTop:'1px solid rgba(212,168,67,0.2)',marginTop:'14px'}}>
      <span style={{fontFamily:'JetBrains Mono,monospace',fontSize:'11px',color:'rgba(212,168,67,0.6)',letterSpacing:'0.05em',textTransform:'uppercase'}}>
        Tonnes CO₂ emitted since you opened this page:&nbsp;
      </span>
      <span style={{fontFamily:'JetBrains Mono,monospace',fontSize:'14px',color:'#D4A843',fontWeight:700,letterSpacing:'0.1em'}}>
        {tonnes.toLocaleString()}
      </span>
    </div>
  );
}
