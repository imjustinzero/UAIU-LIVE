import { useEffect, useState, useRef } from "react";

// ── TYPES ─────────────────────────────────────────────────
interface IntelCard {
  eyebrow: string;
  headline: string;
  summary: string;
  sentiment: 'bullish' | 'bearish' | 'neutral';
}

interface RFQParsed {
  company?: string;
  side?: string;
  standard?: string;
  volume_tonnes?: number;
  target_price_eur?: number;
  deadline?: string;
  notes?: string;
}

// ── MOCK FALLBACK DATA ─────────────────────────────────────
const MOCK_INTEL: IntelCard[] = [
  {
    eyebrow: 'EU ETS UPDATE',
    headline: 'EU Carbon Allowances Hold Above €63 Amid Tightening Supply',
    summary: 'European carbon allowances remained resilient as industrial demand continued to absorb available supply. Analysts expect further tightening through Q3 as the EU phases down free allocations for maritime operators.',
    sentiment: 'bullish'
  },
  {
    eyebrow: 'MARITIME COMPLIANCE',
    headline: 'Cruise Sector Faces €2.1B Carbon Liability in 2026',
    summary: 'New analysis from Transport & Environment estimates the global cruise industry faces over €2.1 billion in EU ETS obligations this year. Caribbean-origin credits with sovereign price floor protection are drawing strong institutional interest.',
    sentiment: 'bullish'
  },
  {
    eyebrow: 'CARIBBEAN SUPPLY',
    headline: 'Blue Carbon Projects in Tonga and Antigua Enter Verification Pipeline',
    summary: 'SwissX-affiliated coral restoration projects in the Pacific and Caribbean have entered the ACR verification pipeline. Verified supply is expected to reach institutional markets within 60 days, with pre-sale RFQs already being processed.',
    sentiment: 'bullish'
  }
];

// ── AI MARKET INTELLIGENCE ─────────────────────────────────
export function AIMarketIntelligence({ isDark = true }: { isDark?: boolean }) {
  const [cards, setCards] = useState<IntelCard[]>(MOCK_INTEL);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [isDemo, setIsDemo] = useState(true);

  const fetchIntel = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/market-intel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timestamp: Date.now() }),
        signal: AbortSignal.timeout(15000)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.cards?.length === 3) {
          setCards(data.cards);
          setIsDemo(false);
          setLastUpdated(new Date());
        }
      }
    } catch {
      // silently use mock data
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIntel();
    const interval = setInterval(fetchIntel, 4 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const sentimentColor = (s: string) =>
    s === 'bullish' ? '#4ade80' : s === 'bearish' ? '#f87171' : '#D4A843';

  const bg = isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.04)';

  return (
    <section id="intelligence" style={{
      padding: 'clamp(60px,8vw,100px) clamp(20px,5vw,80px)',
      background: isDark
        ? 'linear-gradient(180deg,#06060c 0%,#0a0a0f 100%)'
        : 'linear-gradient(180deg,#f8f9fa 0%,#ffffff 100%)'
    }}>
      <div style={{maxWidth:'1200px',margin:'0 auto'}}>
        {/* Header */}
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-end',marginBottom:'40px',flexWrap:'wrap',gap:'12px'}}>
          <div>
            <p style={{margin:'0 0 8px',fontSize:'11px',fontWeight:700,letterSpacing:'0.15em',
              textTransform:'uppercase',color:'#D4A843'}}>
              ◈ AI POWERED
            </p>
            <h2 style={{margin:0,fontSize:'clamp(24px,4vw,36px)',fontWeight:800,
              color: isDark ? '#ffffff' : '#0d1b3e', letterSpacing:'-0.02em'}}>
              Market Intelligence.
            </h2>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:'12px'}}>
            {isDemo && (
              <span style={{fontSize:'10px',color:'rgba(212,168,67,0.5)',
                fontFamily:'JetBrains Mono,monospace',letterSpacing:'0.05em'}}>
                DEMO MODE
              </span>
            )}
            <span style={{fontSize:'10px',color:'rgba(255,255,255,0.3)',
              fontFamily:'JetBrains Mono,monospace'}}>
              Updated {lastUpdated.toLocaleTimeString()}
            </span>
            <button onClick={fetchIntel} disabled={loading} style={{
              padding:'6px 14px',borderRadius:'8px',border:'1px solid rgba(212,168,67,0.3)',
              background:'transparent',color:'#D4A843',fontSize:'11px',
              cursor:loading?'wait':'pointer',letterSpacing:'0.05em',fontWeight:600
            }}>
              {loading ? '⟳ REFRESHING' : '↺ REFRESH'}
            </button>
          </div>
        </div>

        {/* Cards */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(300px,1fr))',gap:'20px'}}>
          {cards.map((card, i) => (
            <div key={i} style={{
              background: bg,
              border: '1px solid rgba(212,168,67,0.15)',
              borderRadius:'16px', padding:'28px',
              borderTop:`3px solid ${sentimentColor(card.sentiment)}`,
              transition:'transform 0.2s,box-shadow 0.2s'
            }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-4px)';
                (e.currentTarget as HTMLDivElement).style.boxShadow = '0 20px 40px rgba(0,0,0,0.3)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLDivElement).style.transform = 'translateY(0)';
                (e.currentTarget as HTMLDivElement).style.boxShadow = 'none';
              }}
            >
              <p style={{margin:'0 0 10px',fontSize:'10px',fontWeight:700,
                letterSpacing:'0.15em',textTransform:'uppercase',
                color: sentimentColor(card.sentiment)}}>
                {card.eyebrow}
              </p>
              <h3 style={{margin:'0 0 14px',fontSize:'16px',fontWeight:700,lineHeight:1.3,
                color: isDark ? '#ffffff' : '#0d1b3e'}}>
                {card.headline}
              </h3>
              <p style={{margin:0,fontSize:'13px',lineHeight:1.7,
                color: isDark ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.6)'}}>
                {card.summary}
              </p>
              <div style={{marginTop:'16px',display:'flex',alignItems:'center',gap:'6px'}}>
                <span style={{
                  padding:'3px 8px',borderRadius:'4px',fontSize:'10px',fontWeight:700,
                  letterSpacing:'0.08em',textTransform:'uppercase',
                  background: sentimentColor(card.sentiment) + '22',
                  color: sentimentColor(card.sentiment)
                }}>
                  {card.sentiment}
                </span>
                <span style={{fontSize:'10px',color:'rgba(255,255,255,0.3)',
                  fontFamily:'JetBrains Mono,monospace'}}>
                  AI GENERATED
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── CLAUDE RFQ ASSISTANT ──────────────────────────────────
interface ClaudeRFQAssistantProps {
  onParsed: (data: RFQParsed) => void;
  isDark?: boolean;
}

export function ClaudeRFQAssistant({ onParsed, isDark = true }: ClaudeRFQAssistantProps) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setError('');
    setMessage('');

    try {
      const res = await fetch('/api/ai/parse-rfq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: input }),
        signal: AbortSignal.timeout(15000)
      });
      if (res.ok) {
        const data = await res.json();
        if (data.rfq) {
          onParsed(data.rfq);
          setMessage('✓ Form filled from your description. Review and submit below.');
          setOpen(false);
        }
      } else {
        // Demo fallback: parse locally
        const vol = input.match(/(\d[\d,]*)\s*(thousand|k)?\s*tonn/i);
        const parsed: RFQParsed = {
          side: /sell/i.test(input) ? 'sell' : 'buy',
          standard: /corsia/i.test(input) ? 'CORSIA' :
                    /gold/i.test(input) ? 'Gold Standard' :
                    /acr/i.test(input) ? 'ACR' : 'VCS',
          volume_tonnes: vol ? parseInt(vol[1].replace(/,/g,'')) * (/thousand|k/i.test(vol[2]||'') ? 1000 : 1) : 5000,
          notes: input
        };
        onParsed(parsed);
        setMessage('✓ Form filled (demo mode). Review and submit below.');
        setOpen(false);
      }
    } catch {
      setError('Unable to reach AI — try describing your needs directly in the form below.');
    } finally {
      setLoading(false);
    }
  };

  const bg = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';
  const border = 'rgba(212,168,67,0.3)';

  return (
    <div style={{marginBottom:'24px'}}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          display:'flex',alignItems:'center',gap:'8px',
          padding:'10px 20px',borderRadius:'10px',
          border:`1px solid ${border}`,background:bg,
          color:'#D4A843',fontSize:'13px',fontWeight:600,
          cursor:'pointer',letterSpacing:'0.05em',marginBottom:'12px'
        }}
      >
        <span style={{fontSize:'16px'}}>✦</span>
        {open ? 'Close AI Assistant' : 'Try AI RFQ Assistant'}
        <span style={{fontSize:'10px',opacity:0.6,marginLeft:'4px'}}>
          describe what you need in plain English
        </span>
      </button>

      {open && (
        <div style={{
          background: bg, border:`1px solid ${border}`,
          borderRadius:'12px', padding:'20px', marginBottom:'16px'
        }}>
          <p style={{margin:'0 0 12px',fontSize:'12px',color:'rgba(212,168,67,0.8)',
            fontFamily:'JetBrains Mono,monospace',letterSpacing:'0.05em'}}>
            AI RFQ ASSISTANT — Powered by Claude
          </p>
          <p style={{margin:'0 0 12px',fontSize:'13px',
            color: isDark ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.6)'}}>
            Describe what you need and Claude will fill the form for you.
          </p>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder={'e.g. "I need 50,000 tonnes of blue carbon CORSIA credits for EU ETS compliance by end of Q3, targeting under €65/tonne for a shipping company"'}
            rows={3}
            style={{
              width:'100%',padding:'12px',borderRadius:'8px',
              border:`1px solid ${border}`,
              background: isDark ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.8)',
              color: isDark ? '#ffffff' : '#0d1b3e',
              fontSize:'13px',resize:'vertical',
              fontFamily:'inherit',boxSizing:'border-box'
            }}
          />
          <div style={{display:'flex',gap:'10px',marginTop:'10px',alignItems:'center'}}>
            <button
              onClick={handleSubmit}
              disabled={loading || !input.trim()}
              style={{
                padding:'10px 24px',borderRadius:'8px',border:'none',
                background: loading ? 'rgba(212,168,67,0.3)' : '#D4A843',
                color:'#0a0a0f',fontWeight:700,fontSize:'13px',
                cursor: loading ? 'wait' : 'pointer',letterSpacing:'0.05em'
              }}
            >
              {loading ? '⟳ Parsing...' : 'Fill Form →'}
            </button>
            {message && <span style={{fontSize:'12px',color:'#4ade80'}}>{message}</span>}
            {error && <span style={{fontSize:'12px',color:'#f87171'}}>{error}</span>}
          </div>
        </div>
      )}
    </div>
  );
}
