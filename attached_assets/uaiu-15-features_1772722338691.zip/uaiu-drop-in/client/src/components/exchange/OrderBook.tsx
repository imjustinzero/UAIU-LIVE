import { useEffect, useState } from "react";

// ── EU ETS PRICE FEED ─────────────────────────────────────
interface ETSPrice {
  price: number;
  change: number;
  changePct: number;
  spread: number;
  loading: boolean;
}

export function useETSPrice(caribbeanPrice: number) {
  const [ets, setEts] = useState<ETSPrice>({
    price: 63.20, change: -0.40, changePct: -0.63,
    spread: caribbeanPrice - 63.20, loading: true
  });

  useEffect(() => {
    const fetchPrice = async () => {
      try {
        // Try Ember Climate API
        const res = await fetch('https://api.ember-climate.org/v1/carbon-price/latest', {
          signal: AbortSignal.timeout(4000)
        });
        if (res.ok) {
          const data = await res.json();
          const price = data?.price ?? 63.20;
          setEts(prev => ({
            price, change: price - 63.60,
            changePct: ((price - 63.60) / 63.60) * 100,
            spread: caribbeanPrice - price, loading: false
          }));
          return;
        }
      } catch {}
      // Fallback: realistic random walk around €63
      const base = 63.20 + (Math.random() - 0.5) * 2;
      setEts({
        price: +base.toFixed(2),
        change: +(base - 63.60).toFixed(2),
        changePct: +((base - 63.60) / 63.60 * 100).toFixed(2),
        spread: +(caribbeanPrice - base).toFixed(2),
        loading: false
      });
    };

    fetchPrice();
    const interval = setInterval(fetchPrice, 300000); // refresh every 5 min
    return () => clearInterval(interval);
  }, [caribbeanPrice]);

  return ets;
}

// ── ORDER BOOK ────────────────────────────────────────────
interface OrderLevel {
  price: number;
  volume: number;
  total: number;
  depth: number; // 0-100 for bar width
}

function genBook(midPrice: number, side: 'bid' | 'ask') {
  const levels: OrderLevel[] = [];
  let cumTotal = 0;
  for (let i = 0; i < 5; i++) {
    const offset = (i + 1) * (0.08 + Math.random() * 0.06);
    const price = side === 'bid'
      ? +(midPrice - offset).toFixed(2)
      : +(midPrice + offset).toFixed(2);
    const volume = Math.floor(500 + Math.random() * 4500);
    cumTotal += volume;
    levels.push({ price, volume, total: cumTotal, depth: 0 });
  }
  // normalize depth
  const maxTotal = levels[levels.length - 1].total;
  levels.forEach(l => { l.depth = Math.round((l.total / maxTotal) * 100); });
  return levels;
}

interface OrderBookProps {
  midPrice: number;
  isDark?: boolean;
}

export function OrderBook({ midPrice, isDark = true }: OrderBookProps) {
  const [bids, setBids] = useState<OrderLevel[]>([]);
  const [asks, setAsks] = useState<OrderLevel[]>([]);
  const [activeTab, setActiveTab] = useState<'both'|'bids'|'asks'>('both');

  useEffect(() => {
    const refresh = () => {
      setBids(genBook(midPrice, 'bid'));
      setAsks(genBook(midPrice, 'ask').reverse());
    };
    refresh();
    const t = setInterval(refresh, 8000);
    return () => clearInterval(t);
  }, [midPrice]);

  const spread = asks.length && bids.length
    ? +(asks[asks.length - 1].price - bids[0].price).toFixed(2)
    : 0;

  const card: React.CSSProperties = {
    background: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.04)',
    border: '1px solid rgba(212,168,67,0.15)',
    borderRadius: '12px', padding: '20px', marginTop: '20px'
  };
  const th: React.CSSProperties = {
    fontFamily: 'JetBrains Mono,monospace', fontSize: '10px',
    color: 'rgba(212,168,67,0.6)', letterSpacing: '0.08em',
    textTransform: 'uppercase', paddingBottom: '8px'
  };

  const Row = ({ level, side }: { level: OrderLevel; side: 'bid'|'ask' }) => (
    <div style={{position:'relative',display:'grid',gridTemplateColumns:'1fr 1fr 1fr',
      gap:'8px',padding:'4px 0',fontFamily:'JetBrains Mono,monospace',fontSize:'12px'}}>
      <div style={{
        position:'absolute',right:0,top:0,bottom:0,
        width:`${level.depth}%`,
        background: side === 'bid'
          ? 'rgba(74,222,128,0.07)' : 'rgba(248,113,113,0.07)',
        borderRadius:'2px', pointerEvents:'none'
      }} />
      <span style={{color: side==='bid' ? '#4ade80' : '#f87171', position:'relative'}}>
        €{level.price.toFixed(2)}
      </span>
      <span style={{color:'rgba(255,255,255,0.7)',textAlign:'right',position:'relative'}}>
        {level.volume.toLocaleString()}
      </span>
      <span style={{color:'rgba(255,255,255,0.4)',textAlign:'right',position:'relative'}}>
        {level.total.toLocaleString()}
      </span>
    </div>
  );

  return (
    <div style={card}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:'16px'}}>
        <h3 style={{margin:0,fontSize:'14px',fontWeight:700,color:'#D4A843',letterSpacing:'0.05em'}}>
          ORDER BOOK
        </h3>
        <div style={{display:'flex',gap:'6px'}}>
          {(['both','bids','asks'] as const).map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)} style={{
              padding:'4px 10px', borderRadius:'6px', border:'none',
              fontSize:'11px', fontWeight:600, cursor:'pointer',
              background: activeTab===tab ? '#D4A843' : 'rgba(212,168,67,0.1)',
              color: activeTab===tab ? '#0a0a0f' : '#D4A843',
              textTransform:'uppercase', letterSpacing:'0.05em'
            }}>{tab}</button>
          ))}
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'8px',marginBottom:'6px'}}>
        <span style={th}>Price (EUR)</span>
        <span style={{...th,textAlign:'right'}}>Volume (t)</span>
        <span style={{...th,textAlign:'right'}}>Total (t)</span>
      </div>

      {(activeTab === 'both' || activeTab === 'asks') && (
        <div style={{marginBottom:'4px'}}>
          {asks.map((a,i) => <Row key={i} level={a} side="ask" />)}
        </div>
      )}

      {activeTab === 'both' && (
        <div style={{
          textAlign:'center',padding:'6px 0',
          fontFamily:'JetBrains Mono,monospace',fontSize:'12px',
          borderTop:'1px solid rgba(212,168,67,0.2)',
          borderBottom:'1px solid rgba(212,168,67,0.2)',
          margin:'6px 0'
        }}>
          <span style={{color:'rgba(255,255,255,0.5)'}}>SPREAD&nbsp;</span>
          <span style={{color:'#D4A843',fontWeight:700}}>€{spread.toFixed(2)}</span>
          <span style={{color:'rgba(255,255,255,0.3)',marginLeft:'12px'}}>
            MID €{midPrice.toFixed(2)}
          </span>
        </div>
      )}

      {(activeTab === 'both' || activeTab === 'bids') && (
        <div>
          {bids.map((b,i) => <Row key={i} level={b} side="bid" />)}
        </div>
      )}
    </div>
  );
}
