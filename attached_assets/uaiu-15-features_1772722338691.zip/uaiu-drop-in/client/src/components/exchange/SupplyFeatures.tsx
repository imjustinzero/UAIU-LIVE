import { useState } from "react";

// ── FARM CARBON CALCULATOR ─────────────────────────────────
const CA_COUNTIES = [
  "Alameda","Alpine","Amador","Butte","Calaveras","Colusa","Contra Costa",
  "Del Norte","El Dorado","Fresno","Glenn","Humboldt","Imperial","Inyo",
  "Kern","Kings","Lake","Lassen","Los Angeles","Madera","Marin","Mariposa",
  "Mendocino","Merced","Modoc","Mono","Monterey","Napa","Nevada","Orange",
  "Placer","Plumas","Riverside","Sacramento","San Benito","San Bernardino",
  "San Diego","San Francisco","San Joaquin","San Luis Obispo","San Mateo",
  "Santa Barbara","Santa Clara","Santa Cruz","Shasta","Sierra","Siskiyou",
  "Solano","Sonoma","Stanislaus","Sutter","Tehama","Trinity","Tulare",
  "Tuolumne","Ventura","Yolo","Yuba"
];

const CROP_RATES: Record<string, number> = {
  "Rice": 0.8,
  "Dairy": 2.4,
  "Almonds": 0.6,
  "Walnuts": 0.55,
  "Tomatoes": 0.3,
  "Row Crops": 0.35,
  "Cover Crops": 0.45,
  "Other": 0.4
};

const PRACTICE_MULTIPLIERS: Record<string, number> = {
  "No-till": 1.3,
  "Cover crops": 1.2,
  "Alternate wet/dry": 1.4,
  "Manure digester": 2.1,
  "Drip irrigation": 1.15
};

interface CalcResult {
  tonnes: number;
  revenue: number;
  breakdown: { label: string; value: string }[];
}

interface FarmCalculatorProps {
  currentIndexPrice: number;
  onSubmitFarm: (data: any) => void;
  isDark?: boolean;
}

export function FarmCarbonCalculator({ currentIndexPrice, onSubmitFarm, isDark = true }: FarmCalculatorProps) {
  const [farmName, setFarmName] = useState('');
  const [cropType, setCropType] = useState('');
  const [acreage, setAcreage] = useState('');
  const [county, setCounty] = useState('');
  const [practices, setPractices] = useState<string[]>([]);
  const [result, setResult] = useState<CalcResult | null>(null);

  const togglePractice = (p: string) => {
    setPractices(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
  };

  const calculate = () => {
    if (!cropType || !acreage) return;
    const acres = parseFloat(acreage);
    if (isNaN(acres) || acres <= 0) return;

    let baseRate = CROP_RATES[cropType] || 0.4;
    let multiplier = 1.0;
    practices.forEach(p => {
      multiplier *= (PRACTICE_MULTIPLIERS[p] || 1.0);
    });

    const tonnes = Math.floor(acres * baseRate * multiplier);
    const revenue = Math.floor(tonnes * currentIndexPrice * 0.70); // 70% to farmer

    setResult({
      tonnes,
      revenue,
      breakdown: [
        { label: 'Crop Type', value: cropType },
        { label: 'Acreage', value: `${Number(acreage).toLocaleString()} acres` },
        { label: 'Base Rate', value: `${baseRate} tonnes/acre/year` },
        { label: 'Practice Multiplier', value: `${multiplier.toFixed(2)}x` },
        { label: 'Est. Annual Credits', value: `${tonnes.toLocaleString()} tonnes` },
        { label: 'Your 70% Revenue', value: `$${revenue.toLocaleString()}/year` },
        { label: 'Index Price Used', value: `€${currentIndexPrice.toFixed(2)}/tonne` },
      ]
    });
  };

  const bg = isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.04)';
  const cardBorder = '1px solid rgba(212,168,67,0.15)';
  const inputStyle: React.CSSProperties = {
    width:'100%', padding:'10px 14px', borderRadius:'8px',
    border:'1px solid rgba(212,168,67,0.2)',
    background: isDark ? 'rgba(0,0,0,0.3)' : 'rgba(255,255,255,0.8)',
    color: isDark ? '#ffffff' : '#0d1b3e',
    fontSize:'14px', boxSizing:'border-box', fontFamily:'inherit'
  };
  const labelStyle: React.CSSProperties = {
    display:'block', marginBottom:'6px', fontSize:'11px', fontWeight:700,
    letterSpacing:'0.1em', textTransform:'uppercase',
    color: isDark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)'
  };

  return (
    <section id="calculator" style={{
      padding:'clamp(60px,8vw,100px) clamp(20px,5vw,80px)',
      background: isDark ? '#06060c' : '#f8f9fa'
    }}>
      <div style={{maxWidth:'1000px',margin:'0 auto'}}>
        <p style={{margin:'0 0 8px',fontSize:'11px',fontWeight:700,letterSpacing:'0.15em',
          textTransform:'uppercase',color:'#D4A843'}}>🌾 SUPPLY SIDE</p>
        <h2 style={{margin:'0 0 8px',fontSize:'clamp(24px,4vw,36px)',fontWeight:800,
          color: isDark ? '#ffffff' : '#0d1b3e',letterSpacing:'-0.02em'}}>
          Farm Carbon Calculator.
        </h2>
        <p style={{margin:'0 0 40px',fontSize:'15px',color: isDark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)'}}>
          Find out how much your land is worth on the carbon market. Zero cost. 70% of revenue goes to you.
        </p>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'20px',
          background:bg,border:cardBorder,borderRadius:'16px',padding:'32px'}}>

          {/* Left: Form */}
          <div style={{display:'flex',flexDirection:'column',gap:'16px'}}>
            <div>
              <label style={labelStyle}>Farm Name</label>
              <input value={farmName} onChange={e=>setFarmName(e.target.value)}
                placeholder="Optional" style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Crop Type *</label>
              <select value={cropType} onChange={e=>setCropType(e.target.value)} style={inputStyle}>
                <option value="">Select crop type</option>
                {Object.keys(CROP_RATES).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Acreage *</label>
              <input type="number" value={acreage} onChange={e=>setAcreage(e.target.value)}
                placeholder="e.g. 500" style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>County</label>
              <select value={county} onChange={e=>setCounty(e.target.value)} style={inputStyle}>
                <option value="">Select county</option>
                {CA_COUNTIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Current Practices (select all that apply)</label>
              <div style={{display:'flex',flexWrap:'wrap',gap:'8px',marginTop:'4px'}}>
                {Object.keys(PRACTICE_MULTIPLIERS).map(p => (
                  <button key={p} onClick={()=>togglePractice(p)} style={{
                    padding:'6px 12px',borderRadius:'6px',border:'1px solid rgba(212,168,67,0.3)',
                    background: practices.includes(p) ? '#D4A843' : 'transparent',
                    color: practices.includes(p) ? '#0a0a0f' : '#D4A843',
                    fontSize:'12px',fontWeight:600,cursor:'pointer'
                  }}>{p}</button>
                ))}
              </div>
            </div>
            <button onClick={calculate} style={{
              padding:'14px',borderRadius:'10px',border:'none',
              background:'#D4A843',color:'#0a0a0f',fontWeight:700,
              fontSize:'14px',cursor:'pointer',letterSpacing:'0.05em',marginTop:'4px'
            }}>
              Calculate My Carbon Value →
            </button>
          </div>

          {/* Right: Results */}
          <div>
            {result ? (
              <div style={{
                background: isDark ? 'rgba(212,168,67,0.05)' : 'rgba(212,168,67,0.08)',
                border:'2px solid rgba(212,168,67,0.3)',borderRadius:'12px',padding:'24px'
              }}>
                <p style={{margin:'0 0 4px',fontSize:'11px',fontWeight:700,
                  letterSpacing:'0.1em',color:'rgba(212,168,67,0.6)'}}>
                  ESTIMATED ANNUAL REVENUE
                </p>
                <p style={{margin:'0 0 4px',fontFamily:'JetBrains Mono,monospace',
                  fontSize:'36px',fontWeight:700,color:'#D4A843'}}>
                  ${result.revenue.toLocaleString()}
                </p>
                <p style={{margin:'0 0 20px',fontSize:'12px',color:'rgba(255,255,255,0.5)'}}>
                  {result.tonnes.toLocaleString()} verified carbon tonnes · 70% farmer share
                </p>
                <div style={{display:'flex',flexDirection:'column',gap:'8px',marginBottom:'20px'}}>
                  {result.breakdown.map((b,i) => (
                    <div key={i} style={{display:'flex',justifyContent:'space-between',
                      fontSize:'12px',padding:'4px 0',
                      borderBottom:'1px solid rgba(212,168,67,0.1)'}}>
                      <span style={{color:'rgba(255,255,255,0.5)'}}>{b.label}</span>
                      <span style={{color: isDark ? '#ffffff' : '#0d1b3e',fontWeight:600,
                        fontFamily:'JetBrains Mono,monospace'}}>{b.value}</span>
                    </div>
                  ))}
                </div>
                <button onClick={() => onSubmitFarm({
                  org_name: farmName,
                  credit_type: cropType,
                  volume_tonnes: result.tonnes,
                  county,
                  practices
                })} style={{
                  width:'100%',padding:'12px',borderRadius:'8px',border:'none',
                  background:'#D4A843',color:'#0a0a0f',fontWeight:700,
                  fontSize:'13px',cursor:'pointer',letterSpacing:'0.05em'
                }}>
                  Submit My Farm to UAIU →
                </button>
              </div>
            ) : (
              <div style={{
                height:'100%',display:'flex',flexDirection:'column',
                justifyContent:'center',alignItems:'center',
                border:'2px dashed rgba(212,168,67,0.2)',borderRadius:'12px',
                padding:'40px',textAlign:'center'
              }}>
                <p style={{fontSize:'40px',margin:'0 0 12px'}}>🌾</p>
                <p style={{fontSize:'14px',color:'rgba(255,255,255,0.4)',margin:0}}>
                  Fill in your farm details to see your estimated annual carbon revenue
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

// ── PROJECT PIPELINE TRACKER ───────────────────────────────
interface PipelineProject {
  name: string;
  location: string;
  flag: string;
  standard: string;
  est_tonnes: number;
  expected_listing: string;
  status: 'Pending' | 'In Review' | 'Verified' | 'Live';
  description: string;
}

const PIPELINE_PROJECTS: PipelineProject[] = [
  {
    name: 'SwissX B100 Caribbean Biofuel',
    location: 'Antigua, Caribbean', flag: '🇦🇬',
    standard: 'CORSIA', est_tonnes: 500000,
    expected_listing: 'Live Now', status: 'Live',
    description: 'Advanced biofuel carbon credits from Caribbean-origin B100 production'
  },
  {
    name: 'Coral Restoration — Tonga Blue Carbon',
    location: 'Kingdom of Tonga, Pacific', flag: '🇹🇴',
    standard: 'VCS Blue Carbon', est_tonnes: 280000,
    expected_listing: 'Live Now', status: 'Live',
    description: 'Coral reef restoration generating verified blue carbon credits in sovereign Pacific waters'
  },
  {
    name: 'REDD++ Honduras Forest Conservation',
    location: 'Roatan, Honduras', flag: '🇭🇳',
    standard: 'VCS REDD++', est_tonnes: 180000,
    expected_listing: 'Live Now', status: 'Live',
    description: 'Mesoamerican reef corridor forest protection with biodiversity co-benefits'
  },
  {
    name: 'East Delta Dena Regenerative Zone',
    location: 'Altadena, California', flag: '🇺🇸',
    standard: 'CAR', est_tonnes: 25000,
    expected_listing: 'Q2 2026', status: 'In Review',
    description: 'Post-wildfire regenerative soil, biochar, and waste-to-energy project in LA County'
  },
  {
    name: 'Tuskegee Regenerative City',
    location: 'Tuskegee, Alabama', flag: '🇺🇸',
    standard: 'ACR', est_tonnes: 40000,
    expected_listing: 'Q2 2026', status: 'In Review',
    description: 'Regenerative agriculture and biochar — ESG + DEI flagship project'
  },
  {
    name: 'Antigua Coastal Resilience',
    location: 'Antigua & Barbuda', flag: '🇦🇬',
    standard: 'Gold Standard Blue Carbon', est_tonnes: 95000,
    expected_listing: 'Q3 2026', status: 'Pending',
    description: 'Coastal wetland and mangrove restoration generating blue carbon and biodiversity credits'
  },
];

const STATUS_COLORS: Record<string, string> = {
  'Pending': '#94a3b8',
  'In Review': '#D4A843',
  'Verified': '#60a5fa',
  'Live': '#4ade80'
};

export function ProjectPipeline({ isDark = true }: { isDark?: boolean }) {
  const bg = isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.04)';

  return (
    <section id="pipeline" style={{
      padding:'clamp(60px,8vw,100px) clamp(20px,5vw,80px)',
      background: isDark
        ? 'linear-gradient(180deg,#0a0a0f 0%,#06060c 100%)'
        : 'linear-gradient(180deg,#ffffff 0%,#f0f4f8 100%)'
    }}>
      <div style={{maxWidth:'1200px',margin:'0 auto'}}>
        <p style={{margin:'0 0 8px',fontSize:'11px',fontWeight:700,letterSpacing:'0.15em',
          textTransform:'uppercase',color:'#D4A843'}}>◈ SUPPLY PIPELINE</p>
        <h2 style={{margin:'0 0 8px',fontSize:'clamp(24px,4vw,36px)',fontWeight:800,
          color: isDark ? '#ffffff' : '#0d1b3e',letterSpacing:'-0.02em'}}>
          Project Pipeline.
        </h2>
        <p style={{margin:'0 0 40px',fontSize:'15px',
          color: isDark ? 'rgba(255,255,255,0.5)' : 'rgba(0,0,0,0.5)'}}>
          Verified and pending carbon projects entering the UAIU.LIVE/X marketplace.
        </p>

        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(340px,1fr))',gap:'16px'}}>
          {PIPELINE_PROJECTS.map((p,i) => (
            <div key={i} style={{
              background:bg,border:'1px solid rgba(212,168,67,0.15)',
              borderRadius:'14px',padding:'22px',
              borderLeft:`3px solid ${STATUS_COLORS[p.status]}`
            }}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:'10px'}}>
                <span style={{fontSize:'24px'}}>{p.flag}</span>
                <span style={{
                  padding:'4px 10px',borderRadius:'20px',fontSize:'10px',fontWeight:700,
                  letterSpacing:'0.08em',textTransform:'uppercase',
                  background: STATUS_COLORS[p.status] + '22',
                  color: STATUS_COLORS[p.status]
                }}>{p.status}</span>
              </div>
              <h3 style={{margin:'0 0 6px',fontSize:'14px',fontWeight:700,lineHeight:1.3,
                color: isDark ? '#ffffff' : '#0d1b3e'}}>{p.name}</h3>
              <p style={{margin:'0 0 12px',fontSize:'12px',
                color: isDark ? 'rgba(255,255,255,0.4)' : 'rgba(0,0,0,0.4)'}}>
                📍 {p.location}
              </p>
              <p style={{margin:'0 0 14px',fontSize:'12px',lineHeight:1.6,
                color: isDark ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.55)'}}>
                {p.description}
              </p>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'8px'}}>
                {[
                  { label:'Standard', value: p.standard },
                  { label:'Est. Tonnes', value: p.est_tonnes.toLocaleString() },
                  { label:'Listing', value: p.expected_listing }
                ].map((stat,si) => (
                  <div key={si} style={{textAlign:'center',
                    background: isDark ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.05)',
                    borderRadius:'6px',padding:'8px 4px'}}>
                    <p style={{margin:'0 0 2px',fontSize:'9px',fontWeight:700,
                      letterSpacing:'0.08em',textTransform:'uppercase',
                      color:'rgba(212,168,67,0.6)'}}>{stat.label}</p>
                    <p style={{margin:0,fontSize:'11px',fontWeight:700,
                      fontFamily:'JetBrains Mono,monospace',
                      color: isDark ? '#ffffff' : '#0d1b3e'}}>{stat.value}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
