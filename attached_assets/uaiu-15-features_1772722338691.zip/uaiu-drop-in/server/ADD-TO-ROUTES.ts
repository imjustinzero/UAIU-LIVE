// ============================================================
// ADD THESE ROUTES TO YOUR EXISTING server/routes.ts
// Paste INSIDE the registerRoutes() function
// ============================================================

import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── AI MARKET INTELLIGENCE ────────────────────────────────
app.post("/api/ai/market-intel", async (req, res) => {
  try {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      messages: [{
        role: "user",
        content: `You are a carbon market analyst. Generate exactly 3 current market intelligence cards for the UAIU carbon credit exchange. 
        
Return ONLY valid JSON, no markdown, no backticks:
{
  "cards": [
    {
      "eyebrow": "SHORT CATEGORY LABEL",
      "headline": "News headline under 12 words",
      "summary": "Two sentences summarizing the market development.",
      "sentiment": "bullish" | "bearish" | "neutral"
    }
  ]
}

Topics: EU ETS prices, maritime/cruise carbon compliance, Caribbean blue carbon supply, voluntary carbon market trends. Make it feel like live Bloomberg data. Date context: ${new Date().toLocaleDateString()}.`
      }]
    });

    const text = response.content[0].type === "text" ? response.content[0].text : "";
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    res.json(parsed);
  } catch (e) {
    console.error("Market intel error:", e);
    res.status(500).json({ error: "AI unavailable" });
  }
});

// ── CLAUDE RFQ ASSISTANT ──────────────────────────────────
app.post("/api/ai/parse-rfq", async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: "No prompt" });

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 500,
      messages: [{
        role: "user",
        content: `Parse this carbon credit RFQ request and extract structured data.

User request: "${prompt}"

Return ONLY valid JSON, no markdown, no backticks:
{
  "rfq": {
    "side": "buy" or "sell",
    "standard": "VCS" | "Gold Standard" | "CORSIA" | "ACR" | "CAR" | "Other",
    "volume_tonnes": number,
    "target_price_eur": number or null,
    "deadline": "YYYY-MM-DD" or null,
    "notes": "cleaned up description of what they need"
  }
}

If something is not mentioned, use null. Volume: if they say "50,000 tonnes" use 50000. Price: convert to EUR if needed (USD ≈ EUR for estimates).`
      }]
    });

    const text = response.content[0].type === "text" ? response.content[0].text : "";
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    res.json(parsed);
  } catch (e) {
    console.error("RFQ parse error:", e);
    res.status(500).json({ error: "AI unavailable" });
  }
});

// ── VISION PROJECT VERIFICATION ───────────────────────────
app.post("/api/ai/vision-verify", async (req, res) => {
  try {
    const { image, mediaType } = req.body;
    if (!image) return res.status(400).json({ error: "No image" });

    const validTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    const imgType = validTypes.includes(mediaType) ? mediaType : "image/jpeg";

    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 800,
      messages: [{
        role: "user",
        content: [
          {
            type: "image",
            source: {
              type: "base64",
              media_type: imgType as any,
              data: image
            }
          },
          {
            type: "text",
            text: `You are a carbon project verification analyst for UAIU Holdings Corp. Analyze this project image and generate a preliminary verification report.

Include:
1. LOCATION ASSESSMENT: What type of land/ecosystem is visible
2. VEGETATION ANALYSIS: Estimated coverage and health
3. CARBON SEQUESTRATION ESTIMATE: Estimated tonnes CO2/acre/year range
4. RECOMMENDED STANDARD: Best carbon standard for this project type (VCS, Gold Standard, CAR, ACR, CORSIA)
5. NEXT STEPS: What the project developer should do

Format as plain text report with clear section headers. End with: "NOTE: This is a preliminary AI assessment only and does not constitute formal carbon credit verification."`
          }
        ]
      }]
    });

    const report = response.content[0].type === "text" ? response.content[0].text : "";
    res.json({ report });
  } catch (e) {
    console.error("Vision verify error:", e);
    res.status(500).json({ error: "Vision analysis unavailable" });
  }
});

// ── MULTI-SIG COMPLIANCE APPROVAL EMAIL ───────────────────
app.post("/api/exchange/compliance-approval", async (req, res) => {
  try {
    const { email, tradeId, receiptHash, token, approveUrl } = req.body;

    // Use your existing sendExchangeEmail from email-service.ts
    await sendExchangeEmail({
      to: email,
      subject: `[UAIU] Compliance Approval Required — Trade ${tradeId}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#0d1b2e;color:#ffffff;padding:40px;border-radius:12px;">
          <div style="text-align:center;margin-bottom:32px;">
            <h1 style="color:#D4A843;font-size:24px;margin:0;">UAIU Holdings Corp</h1>
            <p style="color:#888;font-size:14px;margin:8px 0 0;">Carbon Credit Exchange</p>
          </div>
          <h2 style="color:#ffffff;font-size:18px;">Compliance Approval Required</h2>
          <p style="color:#ccc;line-height:1.6;">A carbon credit trade requires your compliance approval before final settlement.</p>
          <div style="background:rgba(212,168,67,0.1);border:1px solid rgba(212,168,67,0.3);border-radius:8px;padding:20px;margin:24px 0;">
            <p style="margin:0 0 8px;color:#D4A843;font-size:12px;font-weight:bold;letter-spacing:0.1em;">TRADE DETAILS</p>
            <p style="margin:4px 0;color:#fff;font-family:monospace;font-size:13px;">Trade ID: ${tradeId}</p>
            <p style="margin:4px 0;color:#aaa;font-family:monospace;font-size:11px;">SHA-256: ${receiptHash?.slice(0,32)}...</p>
          </div>
          <div style="text-align:center;margin:32px 0;">
            <a href="${approveUrl}" style="display:inline-block;padding:16px 40px;background:#D4A843;color:#0a0a0f;border-radius:10px;text-decoration:none;font-weight:bold;font-size:16px;letter-spacing:0.05em;">
              ✓ APPROVE TRADE
            </a>
          </div>
          <p style="color:#666;font-size:12px;text-align:center;">
            This approval request was generated by UAIU.LIVE/X · uaiu.live/x<br/>
            Approval token: ${token}
          </p>
        </div>
      `
    });

    res.json({ success: true });
  } catch (e) {
    console.error("Compliance email error:", e);
    res.status(500).json({ error: "Email send failed" });
  }
});
