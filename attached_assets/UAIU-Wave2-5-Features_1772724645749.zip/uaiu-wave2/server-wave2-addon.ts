// ============================================================
// UAIU WAVE 2 — SERVER ADDITIONS
// ============================================================
// PART A: Add to server/routes.ts (API routes)
// PART B: Add to server/index.ts or wherever socket.io is initialized
// ============================================================

// ════════════════════════════════════════════════════════════
// PART A — ADD TO server/routes.ts
// ════════════════════════════════════════════════════════════

// Add this import at top of routes.ts (Anthropic already imported from wave 1):
// import Anthropic from "@anthropic-ai/sdk"; // already there from wave 1

// ── AI TRADE NEGOTIATOR ENDPOINT ─────────────────────────
/*
app.post("/api/ai/negotiate", async (req, res) => {
  try {
    const { rfq, market } = req.body;
    if (!rfq || !market) return res.status(400).json({ error: "Missing rfq or market data" });

    const prompt = `You are an AI trade negotiator for a carbon credit exchange.
    
RFQ Details:
- Side: ${rfq.side}
- Standard: ${rfq.standard}
- Volume: ${rfq.volume_tonnes} tonnes
- Target Price: ${rfq.target_price_eur ? '€' + rfq.target_price_eur : 'not specified'}
- Deadline: ${rfq.deadline || 'not specified'}

Market Context:
- UAIU Caribbean Premium Index: €${market.index_price}/tonne
- Supply Available: ${market.supply_available} tonnes
- Timestamp: ${market.timestamp}

Respond ONLY with valid JSON, no markdown:
{
  "recommended_price": number,
  "acceptance_probability": number (0-100),
  "rationale": "2 sentence analysis",
  "market_context": "1 sentence market summary",
  "counter_range": { "low": number, "high": number },
  "urgency": "low" | "medium" | "high",
  "signal": "strong_buy" | "buy" | "hold" | "sell" | "strong_sell"
}`;

    const msg = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 500,
      messages: [{ role: "user", content: prompt }]
    });

    const text = msg.content.find(b => b.type === "text")?.text || "{}";
    const clean = text.replace(/```json|```/g, "").trim();
    const recommendation = JSON.parse(clean);
    res.json({ recommendation });
  } catch (e) {
    console.error("Negotiate error:", e);
    res.status(500).json({ error: "Negotiation analysis failed" });
  }
});
*/

// ════════════════════════════════════════════════════════════
// PART B — ADD SOCKET.IO CHAT HANDLERS
// Find where socket.io is initialized in your server
// (likely server/index.ts or server/game-manager.ts)
// Add these handlers inside the io.on('connection') callback
// ════════════════════════════════════════════════════════════

/*
// In-memory chat store (use Redis or DB for production)
const listingChatHistory = new Map<string, any[]>(); // room -> messages[]
const listingOnlineUsers = new Map<string, Set<string>>(); // room -> Set<socketId>

io.on('connection', (socket) => {
  // ... your existing socket handlers ...

  // ── LISTING CHAT ────────────────────────────────────────
  socket.on('join-listing-chat', ({ room, listingId, listingName, userHandle }) => {
    socket.join(room);
    
    // Track online users
    if (!listingOnlineUsers.has(room)) listingOnlineUsers.set(room, new Set());
    listingOnlineUsers.get(room)!.add(socket.id);
    
    // Send history
    const history = listingChatHistory.get(room) || [];
    socket.emit('chat-history', history);
    
    // Broadcast online count
    const count = listingOnlineUsers.get(room)!.size;
    io.to(room).emit('listing-online-count', { listing_id: listingId, count });
    
    // System join message
    const joinMsg = {
      id: crypto.randomUUID(),
      listing_id: listingId,
      sender: 'SYSTEM',
      sender_type: 'system',
      text: `${userHandle} joined the chat`,
      timestamp: new Date().toISOString()
    };
    if (!listingChatHistory.has(room)) listingChatHistory.set(room, []);
    listingChatHistory.get(room)!.push(joinMsg);
    socket.to(room).emit('chat-message', joinMsg);
  });

  socket.on('listing-chat-message', ({ room, message }) => {
    // Store in history (cap at 100 messages per listing)
    if (!listingChatHistory.has(room)) listingChatHistory.set(room, []);
    const history = listingChatHistory.get(room)!;
    history.push(message);
    if (history.length > 100) history.splice(0, history.length - 100);
    
    // Broadcast to room (excluding sender — sender already added optimistically)
    socket.to(room).emit('chat-message', message);
  });

  socket.on('leave-listing-chat', ({ room, listingId }) => {
    socket.leave(room);
    const users = listingOnlineUsers.get(room);
    if (users) {
      users.delete(socket.id);
      io.to(room).emit('listing-online-count', { listing_id: listingId, count: users.size });
    }
  });

  socket.on('disconnect', () => {
    // Clean up all rooms this socket was in
    listingOnlineUsers.forEach((users, room) => {
      if (users.has(socket.id)) {
        users.delete(socket.id);
        const listingId = room.replace('listing-', '');
        io.to(room).emit('listing-online-count', { listing_id: listingId, count: users.size });
      }
    });
  });
});
*/
