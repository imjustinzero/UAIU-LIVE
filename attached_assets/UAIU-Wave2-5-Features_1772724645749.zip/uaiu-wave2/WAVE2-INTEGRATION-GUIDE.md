# UAIU EXCHANGE — WAVE 2: 5 NEW FEATURES
# Replit Agent: Follow these steps IN ORDER.
# All files go in client/src/components/exchange/

## FEATURES IN THIS WAVE
1. Terminal Mode        — Press T, full Bloomberg terminal
2. Voice RFQ           — Speak your order, Claude fills the form
3. Video Trade Room    — Daily.co room on every listing card
4. AI Trade Negotiator — Post-RFQ Claude counteroffer engine
5. Real-time Chat      — Socket.io live chat on every listing

════════════════════════════════════════════════════════════
## STEP 1 — COPY COMPONENT FILES
════════════════════════════════════════════════════════════
Copy to client/src/components/exchange/:
- TerminalMode.tsx
- VoiceRFQ.tsx
- TradeFeatures.tsx      (exports: VideoTradeRoom, AITradeNegotiator)
- ListingChat.tsx


════════════════════════════════════════════════════════════
## STEP 2 — ADD SERVER ROUTES (routes.ts)
════════════════════════════════════════════════════════════
Open server/routes.ts and add this route BEFORE the last closing brace:

```typescript
app.post("/api/ai/negotiate", async (req, res) => {
  try {
    const { rfq, market } = req.body;
    if (!rfq || !market) return res.status(400).json({ error: "Missing data" });

    const msg = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 500,
      messages: [{
        role: "user",
        content: `You are an AI trade negotiator for a carbon credit exchange.
RFQ: ${rfq.side} ${rfq.volume_tonnes} tonnes ${rfq.standard} ${rfq.target_price_eur ? 'target €' + rfq.target_price_eur : ''}
Market: Index €${market.index_price}, Supply ${market.supply_available}t
Respond ONLY with JSON no markdown:
{"recommended_price":number,"acceptance_probability":number,"rationale":"2 sentences","market_context":"1 sentence","counter_range":{"low":number,"high":number},"urgency":"low"|"medium"|"high","signal":"strong_buy"|"buy"|"hold"|"sell"|"strong_sell"}`
      }]
    });
    const text = msg.content.find((b:any) => b.type === "text")?.text || "{}";
    const recommendation = JSON.parse(text.replace(/```json|```/g, "").trim());
    res.json({ recommendation });
  } catch (e) {
    console.error("Negotiate error:", e);
    res.status(500).json({ error: "Failed" });
  }
});
```


════════════════════════════════════════════════════════════
## STEP 3 — ADD SOCKET.IO CHAT HANDLERS
════════════════════════════════════════════════════════════
Find your socket.io io.on('connection') handler.
It is likely in server/index.ts, server/game-manager.ts, or wherever your existing socket events are.

Add INSIDE the io.on('connection', (socket) => { ... }) block:

```typescript
// In-memory chat (add near top of file, outside the connection handler)
const listingChatHistory = new Map<string, any[]>();
const listingOnlineUsers = new Map<string, Set<string>>();

// Inside io.on('connection'):
socket.on('join-listing-chat', ({ room, listingId, listingName, userHandle }: any) => {
  socket.join(room);
  if (!listingOnlineUsers.has(room)) listingOnlineUsers.set(room, new Set());
  listingOnlineUsers.get(room)!.add(socket.id);
  const history = listingChatHistory.get(room) || [];
  socket.emit('chat-history', history);
  const count = listingOnlineUsers.get(room)!.size;
  io.to(room).emit('listing-online-count', { listing_id: listingId, count });
  const joinMsg = {
    id: Math.random().toString(36).slice(2),
    listing_id: listingId,
    sender: 'SYSTEM',
    sender_type: 'system',
    text: `${userHandle} joined`,
    timestamp: new Date().toISOString()
  };
  if (!listingChatHistory.has(room)) listingChatHistory.set(room, []);
  listingChatHistory.get(room)!.push(joinMsg);
  socket.to(room).emit('chat-message', joinMsg);
});

socket.on('listing-chat-message', ({ room, message }: any) => {
  if (!listingChatHistory.has(room)) listingChatHistory.set(room, []);
  const history = listingChatHistory.get(room)!;
  history.push(message);
  if (history.length > 100) history.splice(0, history.length - 100);
  socket.to(room).emit('chat-message', message);
});

socket.on('leave-listing-chat', ({ room, listingId }: any) => {
  socket.leave(room);
  const users = listingOnlineUsers.get(room);
  if (users) {
    users.delete(socket.id);
    io.to(room).emit('listing-online-count', { listing_id: listingId, count: users.size });
  }
});
```

Also add to the existing disconnect handler:
```typescript
// Add inside existing socket.on('disconnect') or create one:
socket.on('disconnect', () => {
  listingOnlineUsers.forEach((users, room) => {
    if (users.has(socket.id)) {
      users.delete(socket.id);
      const listingId = room.replace('listing-', '');
      io.to(room).emit('listing-online-count', { listing_id: listingId, count: users.size });
    }
  });
});
```


════════════════════════════════════════════════════════════
## STEP 4 — UPDATE Exchange.tsx
════════════════════════════════════════════════════════════

### 4a. ADD IMPORTS
```tsx
import { TerminalMode } from '../components/exchange/TerminalMode';
import { VoiceRFQ } from '../components/exchange/VoiceRFQ';
import { VideoTradeRoom, AITradeNegotiator } from '../components/exchange/TradeFeatures';
import { ListingChat } from '../components/exchange/ListingChat';
```

### 4b. ADD STATE
```tsx
// AI Negotiator — shown after RFQ submit
const [rfqForNegotiator, setRfqForNegotiator] = useState<any>(null);
const [showNegotiator, setShowNegotiator] = useState(false);

// User handle for chat (generate once per session)
const [chatHandle] = useState(() =>
  `Trader-${Math.random().toString(36).slice(2,6).toUpperCase()}`
);
```

### 4c. ADD TERMINAL MODE
Place this as the VERY FIRST element inside your return():
```tsx
<TerminalMode
  listings={/* pass your listings array or use default */}
  trades={sessionTrades}
  indexPrice={currentIndexPrice}
  etsPrice={etsData.price}
/>
```
The floating [T] button appears automatically. Press T to toggle.


### 4d. ADD VOICE RFQ
In the #rfq section, above the ClaudeRFQAssistant (from wave 1):
```tsx
<VoiceRFQ
  isDark={isDark}
  onParsed={(data) => {
    // Same handler as ClaudeRFQAssistant onParsed
    if (data.side) setRfqSide(data.side);
    if (data.standard) setRfqStandard(data.standard);
    if (data.volume_tonnes) setRfqVolume(String(data.volume_tonnes));
    if (data.target_price_eur) setRfqPrice(String(data.target_price_eur));
    if (data.deadline) setRfqDeadline(data.deadline);
    if (data.notes) setRfqNotes(data.notes);
  }}
/>
```


### 4e. MODIFY handleRfqSubmit()
After your existing RFQ submission logic, add:
```tsx
// Trigger AI negotiator
setRfqForNegotiator({
  side: rfqSide,
  standard: rfqStandard,
  volume_tonnes: parseInt(rfqVolume) || 5000,
  target_price_eur: parseFloat(rfqPrice) || null,
  deadline: rfqDeadline
});
setShowNegotiator(true);
```

Then render the negotiator below the RFQ form:
```tsx
{showNegotiator && rfqForNegotiator && (
  <AITradeNegotiator
    rfqData={rfqForNegotiator}
    currentIndexPrice={currentIndexPrice}
    isDark={isDark}
    onAccept={(price) => {
      setRfqPrice(String(price));
      setShowNegotiator(false);
    }}
  />
)}
```


### 4f. ADD VIDEO ROOM + CHAT TO EACH LISTING CARD
Inside your listing card map (wherever you render each listing), add at the bottom of each card:

```tsx
// Inside listings.map((listing, i) => ( ... ))
// Add after existing Buy/Sell buttons:

<VideoTradeRoom
  listingId={listing.id || String(i)}
  listingName={listing.project_name || listing.name}
  standard={listing.standard}
  price={listing.price_per_tonne || listing.price}
  isDark={isDark}
/>

<ListingChat
  listingId={listing.id || `listing-${i}`}
  listingName={listing.project_name || listing.name}
  userHandle={chatHandle}
  isDark={isDark}
/>
```


════════════════════════════════════════════════════════════
## STEP 5 — FINAL CHECKS
════════════════════════════════════════════════════════════
- [ ] Press T on the exchange — terminal loads with boot sequence
- [ ] Press Escape — terminal closes
- [ ] Click mic button in RFQ — browser asks for mic permission
- [ ] Speak "buy 10000 tonnes VCS" — form fills
- [ ] Click "Request Live Trade Call" on any listing — room URL appears
- [ ] Click "Join Room" — Daily.co opens in new window
- [ ] Click chat button on listing — chat panel opens
- [ ] Type a message — appears in real time
- [ ] Submit an RFQ — AI negotiator recommendation appears below form
- [ ] Click "Accept" on negotiator — price field updates
- [ ] npm run build — no TypeScript errors

## TROUBLESHOOTING
- Terminal not triggering: Check no input is focused when pressing T
- Voice not working: Must be on HTTPS or localhost. Chrome/Edge only.
- Chat not connecting: Verify socket.io handlers added inside io.on('connection')
- Video room failing: Verify DAILY_API_KEY and DAILY_ROOM_DOMAIN secrets are set
- Negotiator showing nothing: Check /api/ai/negotiate route added to routes.ts
